#include <iostream>
#include <cstdlib>
#include <vector>
#include <list>
#include <algorithm> 
#include <numeric>
#include <iterator>

class complex{
private: 
	double re, im; 

public: 
	complex(double init_re=0.0, double init_im=0.0) : re(init_re), im(init_im) {} 
	complex operator+(const complex& other){
		return complex(re+other.re, im+other.im);  
	}
	friend std::ostream& operator<<(std::ostream& os, const complex& c); 
};

std::ostream& operator<<(std::ostream& os, const complex& c){
	os << "(" << c.re << ")+i(" << c.im << ")"; 
	return os; 
} 

template <typename T>
void display_vector_by_index(std::vector<T>& vec, const char* msg){
	std::cout << msg << std::endl; 
	for(std::vector<T>::size_type i = 0; 
		i != vec.size(); 
		++i)
		std::cout << "vec[" << i << "]:" << vec[i] << std::endl; 
	std::cout << "------------------[END]------------------" << std::endl; 
}

void find_demo(void); 
void accumulate_demo(void); 
void equals_demo(void); 
void fill_n_demo(void); 
void back_inserter_demo(void); 
void copy_demo(void); 
void replace_demo(void); 
void sort_demo(void); 

int main(){
	find_demo(); 
	accumulate_demo(); 
	equals_demo(); 
	fill_n_demo(); 
	back_inserter_demo(); 
	copy_demo(); 
	replace_demo(); 
	sort_demo(); 
	return 0; 
}	

void find_demo(void){
	std::vector<int> ivec { 100, 200, 300, 400, 500, 600, 700}; 

	std::vector<int>::const_iterator iter = std::find(ivec.cbegin(), ivec.cend(), 400); 
	if(iter != ivec.end())
		std::cout << "*iter = " << *iter << std::endl; 	
	
	iter = std::find(ivec.begin(), ivec.end(), -400); 
	if(iter != ivec.end())
		std::cout << "*iter = " << *iter << std::endl; 

	std::list<char>L {'a', 'b', 'c', 'd', 'e'}; 
	std::list<char>::const_iterator c_iter; 
	
	c_iter = std::find(L.cbegin(), L.cend(), 'a'); 
	if(c_iter != L.cend())
		std::cout << "*c_iter:" << *c_iter << std::endl; 
	c_iter = std::find(L.cbegin(), L.cend(), 'e'); 
	if(c_iter != L.cend())
		std::cout << "*c_iter:" << *c_iter << std::endl; 	
	std::cout << "------------------[END]------------------" << std::endl; 
}

void accumulate_demo(void){
	std::vector<int> ivec { 100, 200, 300, 400, 500}; 
	std::vector<complex> cvec = {{1.1, 2.2}, {3.3, 4.4}, {5.5, 6.6}}; 

	int sum = std::accumulate(ivec.begin(), ivec.end(), 0); 
	std::cout << "sum:" << sum << std::endl; 

	complex c_sum = std::accumulate(cvec.begin(), cvec.end(), complex()); 
	std::cout << "c_sum:" << c_sum << std::endl; 
	std::cout << "------------------[END]------------------" << std::endl; 
}

void equals_demo(void){
	std::vector<int> ivec{100, 200, 300, 400, 500, 600, 700, 800}; 
	std::list<int> ilist{400, 500, 600, 700, 800}; 

	std::vector<int>::const_iterator b_vec_iter = ivec.cbegin() + 3; 
	std::vector<int>::const_iterator e_vec_iter = ivec.cend(); 
	std::list<int>::const_iterator b_list_iter = ilist.cbegin(); 

	bool rs = std::equal(b_vec_iter, e_vec_iter, b_list_iter); 
	if(rs == true)
		std::cout << "equal" << std::endl; 
	else
		std::cout << "not equal" << std::endl; 

	std::cout << "------------------[END]------------------" << std::endl; 

	// important notes: 

	// 	1. equal algorithms wors on iterators therefore one can use 
	// 	different containers for seq1 and seq2. 
	// 	as show above it is possible to compare vector with list 

	// 	2. Types of objects in two sequences need not be identical 
	//	as long as there is == defined between objects of the 
	//	two distinct element types are being used 

	// 	3. When only three iterators are being used (i.e. we are 
	//	explicitly specifying the end of the second iterator) then 
	//	we must	make sure that second sequences is as long as the first one 
} 

void fill_n_demo(void){
	//	10 vector of integers 
	std::vector<int> ivec(10);

	// vector of 10 floats 
	std::vector<float> fvec(10);

	// vector of 10 complex numbers
	std::vector<complex> cvec;  

	std::fill_n(ivec.begin(), 10, 100); 
	std::fill_n(fvec.begin(), 5, 5.5f); 
	std::fill_n(fvec.begin() + 5, 5, 10.10f); 

	display_vector_by_index(ivec, "Displaying vector of integer"); 
	display_vector_by_index(fvec, "Displaying vector of floats"); 

	// Empty vector of element type int 
	std::vector<int> ivec1; 

	// 	disaster: cannot fill array without allocating memory to its elements 
	// 	std::fill_n(ivec1.begin(), 10, 0); 
}

void back_inserter_demo(void){
	// empty vector of ints 
	std::vector<int> ivec; 
	std::back_insert_iterator<std::vector<int>> b_inserter(ivec); 

	for(int i = 0; i < 5; ++i)
		*b_inserter = (i+1) * 10; 

	std::fill_n(b_inserter, 5, 100); 

	display_vector_by_index(ivec, "back_insertor demo"); 
}

void copy_demo(void){
	int a1[] = {100, 200, 300, 400, 500}; 
	int a2[sizeof(a1)/sizeof(a1[0])]; 
	for(int i = 0; i < sizeof(a1)/sizeof(a1[0]); ++i)
		std::cout << "a2[" << i << "]:" << a2[i] << 
		std::endl;

	std::copy(std::begin(a1), std::end(a1), a2); 

	for(int i = 0; i < sizeof(a1)/sizeof(a1[0]); ++i)
		std::cout << "a2[" << i << "]:" << a2[i] << 
		std::endl; 
	std::cout << "--------------[END]--------------"
	<< std::endl; 
}

void replace_demo(void){
	/* 
	Let iter1 and iter2 be two iterators bound with 
	same containers whose objects are of type T 
	And t1 and t2 are objects of type T 

	std::replace(iter1, iter2, t1, t2); 

	will replace all occurrences of t1 between iter1 to iter2-1
	by t2 
	*/ 
	std::list<int> iList{0, 100, 200, 0, 300, 400, 0}; 
	std::cout << "Befor replace:" << std::endl; 
	for(std::list<int>::iterator iter = iList.begin(); 
		iter != iList.end(); 
		++iter) 
		std::cout << "*iter = " << *iter << std::endl; 
	std::replace(iList.begin(), iList.end(), 0, -5); 
	std::cout << "After replace:" << std::endl; 
	for(std::list<int>::iterator iter = iList.begin(); 
		iter != iList.end(); 
		++iter) 
		std::cout << "*iter = " << *iter << std::endl; 
	std::cout << "--------------[END]--------------"
	<< std::endl; 
} 

void sort_demo(void){
	std::vector<int> ivec {500, 400, 300, 200, 100}; 
	display_vector_by_index(ivec, "Before sort:"); 
	std::sort(ivec.begin(), ivec.end());  
	display_vector_by_index(ivec, "After sort:"); 
}