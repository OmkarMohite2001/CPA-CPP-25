#include <iostream> 
#include <string> 
#include <vector> 
#include <cstdlib>

void find_all(const std::string& s, const std::string& sub_s, std::vector<int>& index_vector); 

int main(void)
{
    std::string s("AAbbAbbbbbAAccAAbbAA"); 
    std::string sub_s("AA"); 
    std::vector<int> indices; 

    find_all(s, sub_s, indices); 
    std::cout << "All occureences of" << sub_s << " in " << s << ":" << std::endl; 
    for(std::vector<int>::size_type i = 0; i != indices.size(); ++i)
        std::cout << "At index:" << indices[i] << std::endl; 

    return (EXIT_SUCCESS); 
}

void find_all(const std::string& s, const std::string& sub_s, std::vector<int>& index_vector)
{   
    std::size_t pos; 
    std::size_t start_index = 0; 

    while((pos = s.find(sub_s, start_index)) != -1)
    {
        index_vector.push_back(pos); 
        start_index = pos + 1; 
    }
}