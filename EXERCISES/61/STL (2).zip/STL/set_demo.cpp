#include <iostream>
#include <set>
#include <cstdlib>

int main(){
	std::set<int> s{10, 20, 30, 40, 10, 20, 30}; 
	std::multiset<int> ms{10, 20, 30, 10, 30, 40, 50, 20}; 

	std::cout << "showing set s:" << std::endl; 
	for(std::set<int>::iterator iter = s.begin(); iter != s.end(); ++iter)
		std::cout << "*iter=" << *iter << std::endl; 

	std::cout << "showing multiset ms:" << std::endl; 
	for(std::multiset<int>::iterator iter = ms.begin(); iter != ms.end(); ++iter)
		std::cout << "*iter:" << *iter << std::endl; 

	return (0); 
}