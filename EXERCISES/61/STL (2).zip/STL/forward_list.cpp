#include <iostream> 
#include <forward_list>
#include <cstdlib>

/* 	insert + delete are more frequent and more important 
	than random access (list, forward_list) (othersie 
	vector or deque)

	shortage of storage 
*/ 

class point3d{
private: 
	double x, y, z; 
public: 
	point3d(double init_x = 0.0, double init_y = 0.0, double init_z = 0.0) : x(init_x), y(init_y),z(init_z)
	{

	}

	friend std::ostream& operator<<(std::ostream& os, const point3d& p); 
}; 

std::ostream& operator<<(std::ostream& os, const point3d& p){
	os << "(" << p.x << "," << p.y << "," << p.z << ")" << std::endl; 
	return os; 
}

template <typename T> 
void show_forward_list_by_iter(std::forward_list<T> &fwd_list, const char* msg){
	std::cout << msg << std::endl; 
	for(std::forward_list<T>::iterator iter = fwd_list.begin(); 
		iter != fwd_list.end(); 
		++iter)
		std::cout << "*iter = " << *iter << std::endl; 
	std::cout << "---------------[END]---------------" << std::endl; 
}


void forward_list_creation(); 
void forward_list_iterator_ops(); 
void forward_list_size_assignment_swap_ops(); 
void forward_list_relational_ops();
void forward_list_addition_ops(); 
void foward_list_insert_emplace_ops(); 
void forward_list_access_ops(); 
void forward_list_erase_ops(); 

int main(){
	forward_list_creation(); 
	forward_list_iterator_ops(); 
	forward_list_size_assignment_swap_ops(); 
	forward_list_relational_ops();
	forward_list_addition_ops(); 
	foward_list_insert_emplace_ops(); 
	forward_list_access_ops();
	forward_list_erase_ops(); 
	return 0; 
}

void forward_list_creation(){
	std::forward_list<int> i_fwd_list; 
	show_forward_list_by_iter(i_fwd_list, "Empty forward list"); 

	std::forward_list<int> i_fwd_list_1 {100, 200, 300, 400, 500}; 
	show_forward_list_by_iter(i_fwd_list_1, "forward list list initialized"); 

	std::forward_list<int> i_fwd_list_2(i_fwd_list_1); 
	show_forward_list_by_iter(i_fwd_list_2, "forward list copy constructed"); 

	std::forward_list<int>::iterator b_iter = i_fwd_list_2.begin(), 
									 e_iter = i_fwd_list_2.begin(); 
	++b_iter; ++e_iter; ++e_iter; ++e_iter; ++e_iter; 
	std::forward_list<int> i_fwd_list_3(b_iter, e_iter); 
	show_forward_list_by_iter(i_fwd_list_3, "forward list iterator initialized"); 

	std::forward_list<int> fwd1(5); 
	show_forward_list_by_iter(fwd1, "foward list : 5 default initialized objects"); 
	std::forward_list<int> fwd2(5, -100); 
	show_forward_list_by_iter(fwd2, "forward_list: 5 explicit initialized objects"); 
}

void forward_list_iterator_ops(){
	std::forward_list<int> i_fwd_list{100, 200, 300, 400, 500}; 

	std::cout << "forward + r/w" << std::endl; 
	for(std::forward_list<int>::iterator iter = i_fwd_list.begin(); 
		iter != i_fwd_list.end(); ++iter)
		std::cout << "*iter = " << *iter << std::endl; 

	std::cout << "forward_list + r only" << std::endl; 
	for(std::forward_list<int>::const_iterator iter = i_fwd_list.cbegin(); 
		iter != i_fwd_list.cend(); 
		++iter)
		std::cout << "*iter = " << *iter << std::endl; 
	std::cout << "---------------[END]---------------" << std::endl; 
} 

void forward_list_size_assignment_swap_ops(){
	std::forward_list<int> fwd1 {100, 200, 300, 400, 500}; 
	std::forward_list<int> fwd2 {10, 20, 30, 40, 50}; 
	std::forward_list<int> fwd3; 
	std::cout << "fwd1.max_size():" << fwd1.max_size() << std::endl; 
	if(fwd1.empty() == false)
		std::cout << "fwd1 is not empty" << std::endl; 
	if(fwd3.empty() == true)
		std::cout << "fwd3 is empty" << std::endl; 
	show_forward_list_by_iter(fwd1, "fwd1 before assignment"); 
	fwd1 = fwd2; 
	show_forward_list_by_iter(fwd1, "fwd1 after assignment"); 
	fwd1 = {1000, 2000, 3000, 4000, 5000}; 
	show_forward_list_by_iter(fwd1, "fwd1 after list assignment c1 = {a, b, c, ... }"); 
	show_forward_list_by_iter(fwd1, "fwd1 before swap"); 
	show_forward_list_by_iter(fwd2, "fwd2 before swap"); 
	fwd1.swap(fwd2); 
	show_forward_list_by_iter(fwd1, "fwd1 after swap"); 
	show_forward_list_by_iter(fwd2, "fwd2 after swap");  

	std::forward_list<int>::iterator b_iter = fwd1.begin(); 
	std::forward_list<int>::iterator e_iter = fwd1.begin(); 
	for(int i = 0; i < 4; ++i)
		++e_iter; 
	fwd3.assign(b_iter, e_iter); 
	show_forward_list_by_iter(fwd3, "fwd3 after iterator assignment"); 
	fwd3.assign({-1, -2, -3, -4}); 
	show_forward_list_by_iter(fwd3, "fwd3 after list assignment"); 
	fwd3.assign(5, -10); 
	show_forward_list_by_iter(fwd3, "fwd3 after assignment by element count and value"); 
}

void forward_list_relational_ops(){
	std::forward_list<int> fwd1{100, 200, 300, 400, 500}; 
	std::forward_list<int> fwd2{100, 2000}; 
	std::forward_list<int> fwd3(fwd1); 
	if(fwd1 < fwd2)
		std::cout << "fwd1 < fwd2 : true" << std::endl; 
	if(fwd2 > fwd1)
		std::cout << "fwd2 > fwd1 : true" << std::endl; 
	if(fwd1 == fwd3)
		std::cout << "fwd1 == fwd3 : true" << std::endl; 
	if(fwd1 != fwd2)
		std::cout << "fwd1 != fwd2 : true" << std::endl; 
	std::cout << "---------------[END]---------------" << std::endl; 
}

void forward_list_addition_ops(){
	std::forward_list<int> fwd; 	
	for(int i = 0; i < 5; ++i)
		fwd.push_front((i+1) * 10); 
	show_forward_list_by_iter(fwd, "after push_front()"); 

	std::forward_list<point3d> fwd_pt; 
	for(int i = 0; i < 5; ++i)
		fwd_pt.emplace_front(i, i+1, i+2); 
	show_forward_list_by_iter(fwd_pt, "after emplace_front()"); 
}

void foward_list_insert_emplace_ops(){
	// 	all these operations are unique to forward_list container 
	// 	not shared by other sequential containers 
	std::forward_list<int> fwd {100, 200, 300, 400, 500}; 
	show_forward_list_by_iter(fwd, "fwd : insert(), emplace() beginning position"); 
	std::forward_list<int>::iterator iter = fwd.begin(); 
	for(int i = 0; i < 2; ++i)
		++iter; 
	iter = fwd.insert_after(iter, -8); 
	show_forward_list_by_iter(fwd, "fwd : insert_after(iter, ele)"); 
	iter = fwd.insert_after(iter, 3, 100); 
	show_forward_list_by_iter(fwd, "fwd : insert_after(iter, times, ele"); 
	iter = fwd.insert_after(iter, {13, 19, 31}); 
	show_forward_list_by_iter(fwd, "fwd : insert_after(iter, list)"); 

	std::forward_list<int> fwd2 {-1000, -2000, -3000, -4000}; 
	iter = fwd.insert_after(iter, fwd2.begin(), fwd2.end()); 
	show_forward_list_by_iter(fwd, "fwd : after insert_after(iter, b_iter, e_iter)"); 

	std::forward_list<point3d> pt_fwd {{0, 0, 0}, {2, 2, 2}, {3, 3, 3}, {4, 4, 4} }; 
	show_forward_list_by_iter(pt_fwd, "pt_fwd : before emplace_after"); 
	std::forward_list<point3d>::iterator pt_iter = pt_fwd.begin(); 
	pt_fwd.emplace_after(pt_iter, 1, 1, 1); 
	show_forward_list_by_iter(pt_fwd, "pt_fwd : after emplace_after"); 

	std::forward_list<int> fwd22 {100, 200, 300, 400}; 
	show_forward_list_by_iter(fwd22, "fwd22 : before insert_after()"); 
	std::forward_list<int>::iterator iter22 = fwd22.before_begin(); 
	iter = fwd2.insert_after(iter22, -100); 
	show_forward_list_by_iter(fwd22, "fwd2 : after insert_after()"); 

	// std::forward_list<int>::const_iterator iter = fwd.before_cbegin() 
	// will return const_iterator just before the beginning position
}

void forward_list_access_ops(){
	std::forward_list<int> fwd {100, 200, 300, 400, 500}; 
	int& first = fwd.front(); 
	std::cout << "The first element in fwd:" << first << std::endl; 
	// 	back() is not supported because its not a doubly linked list 
	//	subscript operator and at() also not supported because linked 
	//	organization does not support random access! 

}

void forward_list_erase_ops(){
	std::forward_list<int> fwd { 100, 200, 300, 400, 500 };
	show_forward_list_by_iter(fwd, "fwd : before pop_front()"); 
	fwd.pop_front(); 
	show_forward_list_by_iter(fwd, "fwd : after pop_front()"); 
	fwd.clear(); 
	show_forward_list_by_iter(fwd, "fwd : after clear()"); 
	// erase() methods customized for forward_list 
	fwd = {100, 200, 300, 400, 500, 600, 700, 800, 900, 100}; 
	std::forward_list<int>::iterator iter = fwd.begin(); 
	++iter; ++iter; ++iter; 
	std::cout << "*iter = " << *iter << std::endl; 
	show_forward_list_by_iter(fwd, "fwd : before erase_after(iter)"); 
	iter = fwd.erase_after(iter); 
	show_forward_list_by_iter(fwd, "fwd : after erase_after(iter)"); 
	iter = fwd.before_begin(); 
	iter = fwd.erase_after(iter); 
	show_forward_list_by_iter(fwd, "fwd : after erase_after(before_begin iter)"); 
	std::forward_list<int>::iterator iter1(iter); 
	++iter1; ++iter1; ++iter1; ++iter1;  
	std::cout << "*iter:" << *iter << std::endl; 
	std::cout << "*iter1:" << *iter1 << std::endl; 
	fwd.erase_after(iter, iter1); 
	show_forward_list_by_iter(fwd, "fwd : after erase(iter1, iter2)"); 
}

/* 
struct node{
	int data; 
	struct node* prev; *next; 
}; 

struct node* create_list(){
	struct node* p_head_node = (struct node*)malloc(sizeof(struct node)); 
	p_head_node->prev = p_head_node; 
	p_head_node->next = p_head_node; 
	p_head_node->data = 0; 
	return p_head_node; 
}

insert*(){
	p_head_node->data++; 
}

size_t get_list_size(struct node* p_head_node){
	return p_head_node->data; 
}
*/ 