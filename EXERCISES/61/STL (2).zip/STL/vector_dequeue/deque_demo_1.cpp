#include <iostream>
#include <cstdlib>
#include <deque>

class Point3d{
private: 
	double x, y, z; 
public: 
	Point3d(double init_x, double init_y, double init_z) : x(init_x), y(init_y), z(init_z) {} 
	friend std::ostream& operator<<(std::ostream& os, const Point3d& pt); 
}; 

 std::ostream& operator<<(std::ostream& os, const Point3d& pt){
 	os << "(" << pt.x << "," << pt.y << "," << pt.z << ")" << std::endl; 
 	return os; 
 }

template <typename T>
void print_deque_by_index(std::deque<T>& D, const char* msg){
	std::cout << msg << std::endl; 
	for(std::deque<T>::size_type i = 0; i != D.size(); ++i)
		std::cout << "D[" << i << "]:" << D[i] << std::endl; 
	std::cout << "------------[END]------------" << std::endl; 
}

template <typename T> 
void print_deque_by_iterator(std::deque<T>& D, const char* msg){
	std::cout << msg << std::endl; 
	for(std::deque<T>::iterator iter = D.begin(); iter != D.end(); ++iter){
		std::cout << "*iter=" << *iter << std::endl; 
	}
	std::cout << "------------[END]------------" << std::endl; 
}

void deque_of_different_types(); 

int main(){
	deque_of_different_types(); 

	return 0; 
}

void deque_of_different_types(){
	std::deque<int> D_int; 
	std::deque<char> D_char{'a', 'b', 'c', 'd'}; 
	std::deque<Point3d> D_points{{1.1,2.2,3.3},{2.2,3.3,4.4},{5.5, 6.6, 7.7}}; 

	print_deque_by_index(D_int, "Empty Deuque of integers"); 
	print_deque_by_iterator(D_char, "deque of chars"); 
	print_deque_by_iterator(D_points, "deque of Point3d"); 
}

