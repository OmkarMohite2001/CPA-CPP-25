#include <iostream>
#include <array>
#include <cstdlib>

class point3d{
private: 
	double x, y, z; 
public: 
	point3d(double init_x = 0.0, double init_y = 0.0, double init_z = 0.0) : x(init_x), y(init_y),z(init_z)
	{

	}

	friend std::ostream& operator<<(std::ostream& os, const point3d& p); 
}; 

std::ostream& operator<<(std::ostream& os, const point3d& p){
	os << "(" << p.x << "," << p.y << "," << p.z << ")" << std::endl; 
	return os; 
}

///////////////////////////////////////////////////////////////////////////////////////

template <typename T, std::size_t n> 
void show_array_by_index(std::array<T, n> &A, const char* msg){
	std::cout << msg << std::endl; 
	for(std::array<T, n>::size_type i = 0; i != A.size(); ++i)
		std::cout << "A[" << i << "]:" << A[i] << std::endl;  
	std::cout << "---------------[END]-----------------" << std::endl; 
}


template <typename T, std::size_t n> 
void show_array_by_iter(std::array<T, n>& A, const char* msg){
	std::cout << msg << std::endl; 
	for(std::array<T, n>::iterator iter = A.begin(); iter != A.end(); ++iter)
		std::cout << "*iter = " << *iter << std::endl; 
	std::cout << "---------------[END]-----------------" << std::endl; 
}

void array_creation_ops(); 
void array_iteration_ops(); 
void array_relational_ops(); 
void array_size_assignment_and_swap_ops(); 
void array_access_ops(); 

int main(){
	array_creation_ops();
	array_iteration_ops(); 
	array_relational_ops(); 
	array_size_assignment_and_swap_ops(); 
	array_access_ops(); 
	return 0; 
}

/* 
template <typename T, int n> 
class Array
{

};

main(){
	Array<int, 5> A; 
}
*/ 

void array_creation_ops(){
	std::array<int, 5> A1; 
	show_array_by_index<int, 5>(A1, "Uninitialized array by index");
	show_array_by_iter<int, 5>(A1, "Uninitialized array by iter"); 

	std::array<int, 5> A2{100, 200, 300, 400, 500};
	show_array_by_index<int, 5>(A2, "A2 by index"); 

	std::array<int, 5> A3(A2); 
	show_array_by_index<int, 5>(A3, "A3 copy constructed"); 

	A1.fill(-4); 
	show_array_by_index<int, 5>(A1, "after initialization by A1.fill(-4)");
}

void array_iteration_ops(){
	std::array<int, 5> A {1000, 2000, 3000, 4000, 5000}; 

	std::cout << "forward + r/w" << std::endl; 
	for(std::array<int, 5>::iterator iter = A.begin(); iter != A.end(); ++iter){
		*iter = *iter + 5; 
		std::cout << "*iter = " << *iter << std::endl; 
	}

	std::cout << "forward + r only" << std::endl; 
	for(std::array<int, 5>::const_iterator iter = A.cbegin(); iter != A.cend(); ++iter)
		std::cout << "*iter = " << *iter << std::endl; 

	std::cout << "backward + rw" << std::endl; 
	for(std::array<int, 5>::reverse_iterator iter = A.rbegin(); iter != A.rend(); ++iter){
		*iter -= 5; 
		std::cout << "*iter = " << *iter << std::endl; 
	}

	std::cout << "backward + r only" << std::endl; 
	for(std::array<int, 5>::const_reverse_iterator iter = A.crbegin(); iter != A.crend(); ++iter)
		std::cout << "*iter = " << *iter << std::endl; 

	std::cout << "---------------[END]-----------------" << std::endl; 
}

void array_relational_ops(){
	std::array<int, 5> A1 {100, 200, 300, 400, 500}; 
	std::array<int, 5> A2 {100, 200, 3000, 400, 500, };  
	std::array<int, 5> A3 (A1); 

	if(A1 == A3)
		std::cout << "A1 and A4 are equal" << std::endl; 

	if(A1 < A2) 
		std::cout << "A1 < A2 is true" << std::endl; 

	if(A1 != A2)
		std::cout << "A1 != A2 is true" << std::endl; 

	std::cout << "---------------[END]-----------------" << std::endl; 
}

void array_size_assignment_and_swap_ops(){
	std::array<int, 5> A1 {100, 200, 300, 400, 500}; 
	std::array<int, 5> A2 {1000, 2000, 3000, 4000, 5000}; 

	show_array_by_index<int, 5>(A1, "Show array before assignment"); 
	A1 = A2; 
	show_array_by_index<int, 5>(A2, "Show array after assignment"); 
	for(std::array<int, 5>::size_type i = 0; i < 5; ++i)
		A1[i] = (i+1) * 100; 
	show_array_by_index<int, 5>(A1, "Show A1 before swap"); 
	show_array_by_index<int, 5>(A2, "Show A2 before swap"); 
	std::swap(A1, A2); 
	show_array_by_index<int, 5>(A1, "Show A1 after swap"); 
	show_array_by_index<int, 5>(A2, "Show A2 after swap"); 

	std::cout << "A1.size():" << A1.size() << std::endl; 
	std::cout << "A1.max_size():" << A1.max_size() << std::endl; 

	if(A1.empty() == false)
		std::cout << "A1 is not empty" << std::endl; 

	std::cout << "---------------[END]-----------------" << std::endl; 
}

void array_access_ops(){
	std::array<int, 5> A {100, 200, 300, 400, 500}; 
	int& first = A.front(); 
	int& last = A.back(); 
	std::cout << "First element in array:" << first << std::endl; 
	std::cout << "Last element in array:" << last << std::endl; 
	std::array<int, 5>::size_type i = 3; 
	std::cout << "A[3]:" << A[3] << std::endl; 
	std::cout << "A.at(3):" << A.at(3) << std::endl; 
	int* pa = A.data(); 
	for(int i = 0; i < 5; ++i)
		std::cout << "*(pa+" << i << "):"  <<*(pa+i) << std::endl; 
	std::cout << "---------------[END]-----------------" << std::endl; 
}
///////////////////////////////////////////////////////////////////////////////////////////////////
/* 

template <typename T, std::size_t n> 
class array{
private: 
	T* a; 
	size_t size; 
public: 
	array(){
		size = n; 
		a = new T[size]; 
	}
}; 

int main(){
	std::array<int, 100> A; 
}

template <typename T> 
T& max(T const& n1, T const& n2){
	if(n1 > n2)
		return n1; 
	return n2; 
}

int main(){
	max<int, int>(10, 20); 
	max(float, float)(1.1f, 2.2f); 
}

template <typename T, std::size_t n>
void f(std::array<T, n>& A){
	for(std::array<T, n>::iterator iter = A.iter(); iter != A.end(); ++iter)
		std::cout << "*iter = " << *iter << std::endl; 
}

int main(){
	std::array<float, 10> fA; 
	f<float, 10>(fA); 
}

*/ 



