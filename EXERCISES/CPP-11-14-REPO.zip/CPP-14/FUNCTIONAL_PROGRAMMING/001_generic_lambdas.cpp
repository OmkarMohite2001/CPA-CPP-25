#include <iostream>
#include <vector>
#include <string>

// C++14 generic lambdas: use auto in parameter list
// each auto parameter becomes an implicit template parameter

void test_basic_generic_lambda(void);
void test_generic_with_containers(void);
void test_polymorphic_callables(void);

int main(void){
	test_basic_generic_lambda();
	test_generic_with_containers();
	test_polymorphic_callables();
	return (0);
}

void test_basic_generic_lambda(void){
	// C++11: must specify types explicitly
	auto add_11 = [](int a, int b) -> int { return a + b; };

	// C++14: auto parameters, works with any type that supports +
	auto add_14 = [](auto a, auto b){ return a + b; };

	std::cout << "add_14(3, 4) = " << add_14(3, 4) << std::endl;
	std::cout << "add_14(1.5, 2.7) = " << add_14(1.5, 2.7) << std::endl;
	std::cout << "add_14(string, string) = "
			  << add_14(std::string("Hello, "), std::string("World!")) << std::endl;
}

void test_generic_with_containers(void){
	// generic print: works with any container
	auto print_all = [](const auto& container){
		for(const auto& elem : container)
			std::cout << elem << " ";
		std::cout << std::endl;
	};

	std::vector<int> ivec{10, 20, 30, 40, 50};
	std::vector<double> dvec{1.1, 2.2, 3.3};
	std::vector<std::string> svec{"Core", "Code", "Academy"};

	print_all(ivec);
	print_all(dvec);
	print_all(svec);
}

void test_polymorphic_callables(void){
	// generic comparison
	auto less_than = [](const auto& a, const auto& b){ return a < b; };

	std::cout << "less_than(3, 5) = " << less_than(3, 5) << std::endl;
	std::cout << "less_than(5.5, 3.3) = " << less_than(5.5, 3.3) << std::endl;
	std::cout << "less_than(\"abc\", \"xyz\") = "
			  << less_than(std::string("abc"), std::string("xyz")) << std::endl;

	// generic square
	auto square = [](auto x){ return x * x; };
	std::cout << "square(5) = " << square(5) << std::endl;
	std::cout << "square(3.14) = " << square(3.14) << std::endl;
}
