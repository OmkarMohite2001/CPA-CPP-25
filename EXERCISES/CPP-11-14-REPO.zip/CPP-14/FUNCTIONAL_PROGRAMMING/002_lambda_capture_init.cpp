#include <iostream>
#include <string>
#include <memory>

// C++14 generalized lambda capture (init-capture)
// [var = expr] creates a new variable in the capture, initialized by expr
// enables move-capture and arbitrary expressions in capture

void test_move_capture(void);
void test_init_expression(void);
void test_unique_ptr_capture(void);

int main(void){
	test_move_capture();
	test_init_expression();
	test_unique_ptr_capture();
	return (0);
}

void test_move_capture(void){
	std::string msg = "Hello from captured move";

	// C++11: cannot move-capture. C++14: init-capture with std::move
	auto f = [captured_msg = std::move(msg)](){
		std::cout << captured_msg << std::endl;
	};

	std::cout << "msg after move: \"" << msg << "\"" << std::endl; 	// empty
	f(); 	// prints the captured string
}

void test_init_expression(void){
	int x = 10;

	// capture a computed value, not a reference to x
	auto f = [y = x * 2](){
		std::cout << "y = " << y << std::endl;
	};

	x = 999; 	// does not affect y
	f(); 		// prints 20

	// rename during capture
	int counter = 0;
	auto increment = [count = counter]() mutable {
		return ++count;
	};

	std::cout << "increment(): " << increment() << std::endl; 	// 1
	std::cout << "increment(): " << increment() << std::endl; 	// 2
	std::cout << "counter: " << counter << std::endl; 			// still 0
}

void test_unique_ptr_capture(void){
	// unique_ptr cannot be copied, only moved
	// C++11 lambdas could not capture unique_ptr at all
	std::unique_ptr<int> ptr(new int(42));

	auto f = [p = std::move(ptr)](){
		std::cout << "unique_ptr value: " << *p << std::endl;
	};

	// ptr is now null
	std::cout << "ptr after move: " << (ptr == nullptr ? "null" : "not null") << std::endl;
	f();
}
