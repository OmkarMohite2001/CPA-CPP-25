#include <iostream>
#include <cmath>

// C++14 variable templates: template that produces a value, not a type or function

template <typename T>
constexpr T pi = T(3.14159265358979323846);

template <typename T>
constexpr T e = T(2.71828182845904523536);

template <typename T>
constexpr T zero = T(0);

// practical: type-dependent epsilon for floating point comparison
template <typename T>
constexpr T epsilon = T(1e-6);

template <>
constexpr float epsilon<float> = 1e-4f; 	// specialization for float

template <typename T>
bool nearly_equal(T a, T b){
	T diff = (a > b) ? (a - b) : (b - a);
	return diff < epsilon<T>;
}

int main(void){
	// pi with different precisions
	float pi_f = pi<float>;
	double pi_d = pi<double>;
	long double pi_ld = pi<long double>;

	std::cout << "pi<float> = " << pi_f << std::endl;
	std::cout << "pi<double> = " << pi_d << std::endl;
	std::cout << "pi<long double> = " << pi_ld << std::endl;

	// use in computation
	double area = pi<double> * 5.0 * 5.0;
	std::cout << "area of circle r=5: " << area << std::endl;

	// nearly_equal with type-appropriate epsilon
	std::cout << "nearly_equal<double>(1.0, 1.0000001) = "
			  << nearly_equal(1.0, 1.0000001) << std::endl;
	std::cout << "nearly_equal<float>(1.0f, 1.0001f) = "
			  << nearly_equal(1.0f, 1.0001f) << std::endl;

	return (0);
}
