#include <iostream>
#include <cstdint>

// C++14: digit separator (single quote) for readability
// purely cosmetic, ignored by compiler

int main(void){
	// decimal
	int million = 1'000'000;
	long long big = 1'234'567'890'123LL;

	// hex
	uint32_t colour = 0xFF'FF'00'00; 	// ARGB: opaque red
	uint32_t addr = 0x0040'1000;

	// binary
	uint16_t mask = 0b1111'0000'1111'0000;

	// floating point
	double pi = 3.141'592'653'589'793;
	double avogadro = 6.022'140'76e23;

	std::cout << "million = " << million << std::endl;
	std::cout << "big = " << big << std::endl;
	std::cout << "colour = 0x" << std::hex << colour << std::dec << std::endl;
	std::cout << "addr = 0x" << std::hex << addr << std::dec << std::endl;
	std::cout << "mask = " << mask << std::endl;
	std::cout << "pi = " << pi << std::endl;

	return (0);
}
