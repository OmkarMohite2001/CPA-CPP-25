#include <iostream>

// C++14 relaxed constexpr: allows loops, if-else, local variables, multiple statements
// C++11 constexpr was limited to a single return statement

// C++11 style: must use recursion
constexpr int factorial_11(int n){
	return (n <= 1) ? 1 : n * factorial_11(n - 1);
}

// C++14 style: loops and local variables allowed
constexpr int factorial_14(int n){
	int result = 1;
	for(int i = 2; i <= n; ++i)
		result *= i;
	return result;
}

// C++14: if-else in constexpr
constexpr int abs_val(int n){
	if(n < 0)
		return -n;
	else
		return n;
}

// C++14: multiple statements, local variables
constexpr int fibonacci(int n){
	if(n <= 1)
		return n;
	int a = 0, b = 1;
	for(int i = 2; i <= n; ++i){
		int tmp = a + b;
		a = b;
		b = tmp;
	}
	return b;
}

// constexpr with array manipulation
constexpr int sum_of_squares(int n){
	int total = 0;
	for(int i = 1; i <= n; ++i)
		total += i * i;
	return total;
}

int main(void){
	constexpr int f5 = factorial_14(5);
	constexpr int f10 = factorial_14(10);
	std::cout << "5! = " << f5 << std::endl;
	std::cout << "10! = " << f10 << std::endl;

	constexpr int a = abs_val(-42);
	std::cout << "abs(-42) = " << a << std::endl;

	constexpr int fib10 = fibonacci(10);
	std::cout << "fib(10) = " << fib10 << std::endl;

	constexpr int ss = sum_of_squares(10);
	std::cout << "sum of squares 1..10 = " << ss << std::endl;

	// compile-time array
	static_assert(factorial_14(6) == 720, "6! must be 720");
	static_assert(fibonacci(7) == 13, "fib(7) must be 13");

	return (0);
}
