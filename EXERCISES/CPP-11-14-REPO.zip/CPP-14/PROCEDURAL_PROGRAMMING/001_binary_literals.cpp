#include <iostream>
#include <cstdint>

// C++14: binary literals with 0b or 0B prefix

void test_binary_literals(void);
void test_bitwise_operations(void);

int main(void){
	test_binary_literals();
	test_bitwise_operations();
	return (0);
}

void test_binary_literals(void){
	int a = 0b1010; 		// 10 in decimal
	int b = 0B11001100; 	// 204 in decimal
	uint8_t byte = 0b11111111; 	// 255

	std::cout << "0b1010 = " << a << std::endl;
	std::cout << "0B11001100 = " << b << std::endl;
	std::cout << "0b11111111 = " << static_cast<int>(byte) << std::endl;

	// useful for register masks and flags
	uint8_t read_flag = 0b00000100; 	// bit 2
	uint8_t write_flag = 0b00000010; 	// bit 1
	uint8_t exec_flag = 0b00000001; 	// bit 0

	uint8_t permissions = read_flag | write_flag; 	// rw-
	std::cout << "permissions = " << static_cast<int>(permissions) << std::endl;
}

void test_bitwise_operations(void){
	uint8_t mask = 0b11110000;
	uint8_t data = 0b10101010;

	uint8_t high_nibble = data & mask;
	uint8_t low_nibble = data & ~mask;

	std::cout << "high nibble = " << static_cast<int>(high_nibble) << std::endl;
	std::cout << "low nibble = " << static_cast<int>(low_nibble) << std::endl;
}
