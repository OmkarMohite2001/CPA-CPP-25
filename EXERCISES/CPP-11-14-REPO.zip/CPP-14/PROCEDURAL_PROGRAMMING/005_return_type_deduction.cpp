#include <iostream>
#include <string>

// C++14: auto return type deduction for regular functions
// C++11 only allowed this for lambdas

// compiler deduces return type from the return statement
auto add(int a, int b){
	return a + b; 	// deduced as int
}

auto multiply(double a, double b){
	return a * b; 	// deduced as double
}

// works with multiple return statements if they all yield the same type
auto classify(int n){
	if(n > 0)
		return std::string("positive");
	else if(n < 0)
		return std::string("negative");
	else
		return std::string("zero");
}

// recursive functions: first return must be non-recursive
auto factorial(int n) -> int { 	// trailing return needed for recursion
	if(n <= 1)
		return 1;
	return n * factorial(n - 1);
}

// auto with references: returns by value (strips reference)
// decltype(auto) preserves reference (see 003_decltype_auto.cpp)
int global_val = 42;

auto get_by_auto(void){
	return global_val; 		// returns int (copy)
}

int main(void){
	auto sum = add(10, 20);
	std::cout << "add(10, 20) = " << sum << std::endl;

	auto product = multiply(3.14, 2.0);
	std::cout << "multiply(3.14, 2.0) = " << product << std::endl;

	std::cout << "classify(5) = " << classify(5) << std::endl;
	std::cout << "classify(-3) = " << classify(-3) << std::endl;
	std::cout << "classify(0) = " << classify(0) << std::endl;

	std::cout << "factorial(7) = " << factorial(7) << std::endl;

	return (0);
}
