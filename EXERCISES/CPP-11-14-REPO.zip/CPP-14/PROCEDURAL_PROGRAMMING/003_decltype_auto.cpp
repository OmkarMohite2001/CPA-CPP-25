#include <iostream>
#include <vector>

// decltype(auto): preserves exact type AND value category
// unlike auto, which strips references and cv-qualifiers

int global = 42;

// returns int& (reference to global)
decltype(auto) get_ref(void){
	return (global); 	// parenthesized: decltype yields int&
}

// returns int (value copy)
decltype(auto) get_val(void){
	return global; 		// unparenthesized: decltype yields int
}

// perfect forwarding of return type
template <typename F, typename... Args>
decltype(auto) call_and_return(F func, Args&&... args){
	return func(std::forward<Args>(args)...);
}

int& identity_ref(int& x){ return x; }
int identity_val(int x){ return x; }

int main(void){
	decltype(auto) ref = get_ref(); 	// int&
	decltype(auto) val = get_val(); 	// int

	ref = 100;
	std::cout << "global after ref = 100: " << global << std::endl; 	// 100

	val = 999;
	std::cout << "global after val = 999: " << global << std::endl; 	// still 100

	// contrast with auto
	auto a = get_ref(); 	// int (auto strips reference)
	a = 200;
	std::cout << "global after auto a = 200: " << global << std::endl; 	// still 100

	// perfect forwarding return
	int n = 50;
	decltype(auto) r = call_and_return(identity_ref, n);
	r = 75;
	std::cout << "n after forwarded ref = 75: " << n << std::endl; 	// 75

	return (0);
}
