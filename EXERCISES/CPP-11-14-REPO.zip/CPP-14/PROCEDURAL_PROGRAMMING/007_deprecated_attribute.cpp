#include <iostream>

// C++14: [[deprecated]] attribute
// generates a compiler warning when the marked entity is used

[[deprecated("use process_v2() instead")]]
void process_v1(int n){
	std::cout << "process_v1(" << n << ")" << std::endl;
}

void process_v2(int n){
	std::cout << "process_v2(" << n << ")" << std::endl;
}

[[deprecated]]
int old_global = 100;

[[deprecated("use NewConfig instead")]]
struct OldConfig{
	int width;
	int height;
};

struct NewConfig{
	int width;
	int height;
	bool fullscreen;
};

// deprecated typedef
[[deprecated("use modern_callback_t instead")]]
typedef void (*legacy_callback_t)(int);

using modern_callback_t = void(*)(int);

int main(void){
	// process_v1(42); 	// warning: 'process_v1' is deprecated: use process_v2() instead
	process_v2(42); 	// ok

	// OldConfig c{800, 600}; 	// warning: 'OldConfig' is deprecated
	NewConfig c{800, 600, false}; 	// ok

	return (0);
}
