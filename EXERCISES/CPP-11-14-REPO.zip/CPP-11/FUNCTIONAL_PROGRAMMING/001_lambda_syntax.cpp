#include <iostream>
#include <string>

bool test();
void capture_by_value();
void capture_by_reference();
void implicit_captures();
void mutable_lambda();

int main(void){
	bool b;

	b = [] (std::string& a, std::string& b) -> bool
			{ return a.size() > b.size();}(std::string("Hello,World"), std::string("abc"));
	std::cout << "b:" << b << std::endl;

	auto b2 = [](std::string& a, std::string& b) {
				return a.size() < b.size();
				} (std::string("abc"), std::string("pqrs"));
	std::cout << "b2:" << b2 << std::endl;

	test();
	capture_by_value();
	capture_by_reference();
	implicit_captures();
	mutable_lambda();

	return (0);
}

bool test(){
	int loc = 500;
	int kb;

	std::cout << "enter kb:";
	std::cin >> kb;

	auto b = [loc, kb] () -> bool { return kb > loc; } ();
	std::cout << "test():b:" << b << std::endl;

	return b;
}

void capture_by_value(){
	int v1 = 42;
	auto f = [v1]()->int{
				return v1;
			};
	v1 = 500;
	auto v2 = f();
	std::cout << "v2:" << v2 << std::endl; 	// 42, not 500
}

void capture_by_reference(){
	int v1 = 500;
	auto f = [&v1]() { return v1; };
	v1 = 600;
	auto v2 = f();
	std::cout << "v2:" << v2 << std::endl; 	// 600
}

void implicit_captures(){
	int i = 100, j = 200, k = 300;

	auto f = [=]() { std::cout << "i:" << i << " j:" << j << " k:" << k << std::endl; };
	auto g = [&]() { std::cout << "i:" << i << " j:" << j << " k:" << k << std::endl; };

	f();
	g();

	i = 1000;
	j = 2000;
	k = 3000;

	f(); 	// still prints 100, 200, 300
	g(); 	// prints 1000, 2000, 3000
}

void mutable_lambda(){
	int i = 42;
	auto f = [i] () mutable -> int{ return ++i; };
	i = 0;
	auto j = f();
	std::cout << "j:" << j << std::endl; 	// 43
	std::cout << "i:" << i << std::endl; 	// 0
}
