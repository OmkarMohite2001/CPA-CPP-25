#include <iostream>
#include <functional>

int my_add(int, int);

int main(void){
	std::function<int(int, int)> func_obj(my_add);

	int result = func_obj(100, 200);
	std::cout << "Result=" << result << std::endl;

	return (0);
}

int my_add(int a, int b){
	return a + b;
}
