#include <iostream>
#include <functional>
#include <cstdio>

void insertion_sort(int* pa, int size);

int main(void){
	std::function<void(int*, int)> sorting_function1;
	std::function<void(int*,int)> sorting_function2(nullptr);
	std::function<void(int*, int)> sorting_function3(insertion_sort);
	std::function<int(int,int)> func_obj([](int a, int b) { return (a + b);});

	if(sorting_function3)
		puts("Does hold the callable object");
	if(!sorting_function2)
		puts("Does not hold the callable object");

	int a[] = {50, 40, 30, 20, 10};
	sorting_function3(a, 5);

	for(int i = 0; i < 5; ++i)
		std::cout << "a[" << i << "]:" << a[i] << std::endl;

	return (0);
}

void insertion_sort(int* pa, int size){
	int i, j;
	int key;

	for(j = 1; j < size; ++j){
		key = pa[j];
		i = j - 1;
		while(i > -1 && pa[i] > key){
			pa[i+1] = pa[i];
			i = i - 1;
		}
		pa[i+1] = key;
	}
}
