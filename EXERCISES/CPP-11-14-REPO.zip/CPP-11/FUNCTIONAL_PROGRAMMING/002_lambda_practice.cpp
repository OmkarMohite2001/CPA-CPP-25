#include <iostream>
#include <vector>
#include <cmath>

void outer_function(void);
void quadratic_solver(void);
void arithmetic_mean(void);
void root_mean_square(void);

int main(void){
	outer_function();
	quadratic_solver();
	arithmetic_mean();
	root_mean_square();
	return (0);
}

void outer_function(void){
	auto square_func = [](double x)->double{
							return x * x;
						};

	double rs = square_func(2);
	std::cout << "Result=" << rs << std::endl;
	rs = square_func(5);
	std::cout << "Result=" << rs << std::endl;
}

void quadratic_solver(void){
	auto q_solver = [](double a, double b, double c) -> std::pair<double, double> {
					std::pair<double, double> roots(NAN, NAN);
					if((b*b - 4*a*c) >= 0.0 && a != 0.0){
						roots.first = (-b + sqrt(b*b-4*a*c))/(2*a);
						roots.second = (-b - sqrt(b*b-4*a*c))/(2*a);
					}
					return roots;
				};

	std::pair<double, double> roots = q_solver(3.0, 5.9, -8.1);
	std::cout << "Roots of 3.0*x^2 + 5.9*x - 8.1 = 0 are:" << std::endl;
	std::cout << roots.first << std::endl;
	std::cout << roots.second << std::endl;
}

void arithmetic_mean(void){
	auto am = [](std::vector<double>& dvec) -> double {
			double summation = 0.0;
			if(dvec.size() == 0)
				return NAN;
			for(std::vector<double>::size_type i = 0; i != dvec.size(); ++i)
				summation += dvec[i];
			return summation / dvec.size();
		};

	std::vector<double> dvec{1.1, 2.2, 3.3, 4.4, 5.5};
	double a_mean = am(dvec);
	std::cout << "a_mean:" << a_mean << std::endl;
}

void root_mean_square(void){
	auto rms = [](std::vector<double>& dvec) -> double {
			double summation = 0.0;
			if(dvec.size() == 0)
				return NAN;
			for(std::vector<double>::size_type i = 0; i != dvec.size(); ++i)
				summation += dvec[i] * dvec[i];
			return sqrt(summation / dvec.size());
		};

	std::vector<double> dvec{1.1, 2.2, 3.3, 4.4, 5.5};
	double d_rms = rms(dvec);
	std::cout << "rms:" << d_rms << std::endl;
}
