#include <iostream>
#include <functional>
#include <vector>

void test(void);

int main(void){
	test();
	return (0);
}

void test(void){
	auto map = [](std::function<int(int)> func, std::vector<int>& v) -> std::vector<int>{
					std::vector<int> rsv;
					for(std::vector<int>::size_type i = 0; i != v.size(); ++i)
						rsv.push_back(func(v[i]));
					return rsv;
				};

	std::vector<int> input{100, 200, 300, 400};
	std::vector<int> r = map([](int x)->int { return x * x ;}, input);
	for(auto iter = r.begin(); iter != r.end(); ++iter)
		std::cout << "*iter=" << *iter << std::endl;
}
