#include <iostream>
#include <vector>
#include <functional>

// C++98 typedef
typedef int int32;
typedef void (*callback_t)(int);

// C++11 type alias: more readable, works with templates
using int64 = long long int;
using func_ptr = void(*)(int);

// template alias: typedef CANNOT do this
template <typename T>
using vec = std::vector<T>;

template <typename T>
using predicate = std::function<bool(T)>;

void print_val(int n){
	std::cout << "n = " << n << std::endl;
}

void test_basic_alias(void);
void test_template_alias(void);

int main(void){
	test_basic_alias();
	test_template_alias();
	return (0);
}

void test_basic_alias(void){
	int64 big_num = 9223372036854775807LL;
	std::cout << "big_num = " << big_num << std::endl;

	func_ptr fp = print_val;
	fp(42);
}

void test_template_alias(void){
	vec<int> ivec{10, 20, 30, 40, 50};
	vec<double> dvec{1.1, 2.2, 3.3};

	for(const auto& v : ivec)
		std::cout << "ivec:" << v << std::endl;

	predicate<int> is_even = [](int x) -> bool { return x % 2 == 0; };
	std::cout << "is_even(4) = " << is_even(4) << std::endl;
	std::cout << "is_even(7) = " << is_even(7) << std::endl;
}
