#include <iostream>

// thread_local: fourth storage duration (alongside automatic, static, dynamic)
// each thread gets its own copy of the variable

// global thread_local: each thread has its own instance
thread_local int tl_counter = 0;

// thread_local can also be combined with static
void increment_counter(const char* thread_name){
	// each thread sees its own tl_counter
	for(int i = 0; i < 3; ++i){
		++tl_counter;
		std::cout << thread_name << ": tl_counter = " << tl_counter << std::endl;
	}
}

// thread_local inside a function: like static, but per-thread
void demo_local_thread_local(void){
	thread_local int call_count = 0; 	// initialized once per thread
	++call_count;
	std::cout << "call_count = " << call_count << std::endl;
}

int main(void){
	// without threads, thread_local behaves like a static variable
	std::cout << "tl_counter before: " << tl_counter << std::endl;

	increment_counter("main");
	std::cout << "tl_counter after: " << tl_counter << std::endl;

	// demonstrates per-call persistence (like static in single-threaded context)
	demo_local_thread_local(); 	// 1
	demo_local_thread_local(); 	// 2
	demo_local_thread_local(); 	// 3

	return (0);
}
