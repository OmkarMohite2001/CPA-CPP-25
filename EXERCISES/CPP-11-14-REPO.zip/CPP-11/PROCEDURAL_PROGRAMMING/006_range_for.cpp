#include <iostream>
#include <vector>

template <typename T>
void show(std::vector<T>& vec){
	for(const auto& v : vec)
		std::cout << "v:" << v << std::endl;
}

int main(void){
	std::vector<int> ivec{10, 20, 30, 40};
	show(ivec);

	std::vector<char> cvec {'a', 'b', 'c', 'd'};
	show(cvec);

	// range-for with modification
	for(auto& v : ivec)
		v = 100;
	show(ivec);

	for(auto& v : cvec)
		v = 'A';
	show(cvec);

	// works on arrays too
	int arr[] = {1, 2, 3, 4, 5};
	for(const auto& v : arr)
		std::cout << "arr:" << v << std::endl;

	return (0);
}
