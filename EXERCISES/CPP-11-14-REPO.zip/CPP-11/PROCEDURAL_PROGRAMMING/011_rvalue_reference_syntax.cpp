#include <iostream>

class Date{
	private:
		int day, month, year;

	public:
		constexpr Date(int init_day, int init_month, int init_year) :
			day(init_day), month(init_month), year(init_year)
		{}

		void set_day(int new_day){
			day = new_day;
		}

		void show() const {
			std::cout << day << "-" << month << "-" << year << std::endl;
		}
};

int main(void){
	int m = 10;
	int&& rr1 = 10; 		// 10 is a prvalue
	int&& rr2 = m + 1; 	// m+1 is a prvalue

	// int&& rr3 = m; 		// error: m is an lvalue

	int&& rr4 = std::move(m); 		// ok, std::move casts lvalue to rvalue reference

	int&& rr5 = reinterpret_cast<int&&>(m); 	// equivalent low-level cast

	Date myDate(17, 8, 2025);

	Date&& refDate1 = reinterpret_cast<Date&&>(myDate);
	Date&& refDate2 = std::move(myDate); 	// preferred way

	return (0);
}
