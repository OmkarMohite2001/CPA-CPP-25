#include <iostream>

// User-defined literals: operator"" _suffix
// Lets you attach meaning to numeric/string literals

// distance in metres, internally stored as metres
struct Distance{
	double metres;
};

// literal operators
constexpr Distance operator"" _m(long double val){
	return Distance{static_cast<double>(val)};
}

constexpr Distance operator"" _km(long double val){
	return Distance{static_cast<double>(val) * 1000.0};
}

constexpr Distance operator"" _cm(long double val){
	return Distance{static_cast<double>(val) / 100.0};
}

// temperature example
struct Celsius{
	double value;
};

struct Fahrenheit{
	double value;
};

constexpr Celsius operator"" _degC(long double val){
	return Celsius{static_cast<double>(val)};
}

constexpr Fahrenheit operator"" _degF(long double val){
	return Fahrenheit{static_cast<double>(val)};
}

// convert Fahrenheit to Celsius
Celsius to_celsius(Fahrenheit f){
	return Celsius{(f.value - 32.0) * 5.0 / 9.0};
}

int main(void){
	auto d1 = 5.0_km;
	auto d2 = 500.0_m;
	auto d3 = 75.0_cm;

	std::cout << "5 km = " << d1.metres << " m" << std::endl;
	std::cout << "500 m = " << d2.metres << " m" << std::endl;
	std::cout << "75 cm = " << d3.metres << " m" << std::endl;

	auto boiling = 212.0_degF;
	Celsius c = to_celsius(boiling);
	std::cout << "212 F = " << c.value << " C" << std::endl;

	auto body_temp = 37.0_degC;
	std::cout << "body temp = " << body_temp.value << " C" << std::endl;

	return (0);
}
