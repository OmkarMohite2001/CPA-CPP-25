#include <iostream>
#include <cstdlib>

// nullptr is a keyword of type std::nullptr_t
// It replaces the C macro NULL which is just 0 or (void*)0

void f(int n){
	std::cout << "f(int):" << n << std::endl;
}

void f(int* p){
	std::cout << "f(int*):" << p << std::endl;
}

void test_overload_ambiguity(void);
void test_nullptr_comparisons(void);

int main(void){
	test_overload_ambiguity();
	test_nullptr_comparisons();
	return (0);
}

void test_overload_ambiguity(void){
	// f(NULL); 		// ambiguous: NULL is 0, could match f(int) or f(int*)
	f(nullptr); 	// unambiguous: calls f(int*)
	f(0); 			// calls f(int)
}

void test_nullptr_comparisons(void){
	int* p = nullptr;
	int* q = new int(100);

	if(p == nullptr)
		std::cout << "p is null" << std::endl;

	if(q != nullptr)
		std::cout << "*q = " << *q << std::endl;

	// nullptr converts to bool as false
	if(!p)
		std::cout << "p evaluates to false" << std::endl;

	delete q;
	q = nullptr;
}
