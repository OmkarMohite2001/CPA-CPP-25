#include <iostream>
#include <stdexcept>

// noexcept specifier: promises that a function does not throw
// if it does throw, std::terminate is called

void safe_function(void) noexcept {
	std::cout << "I will never throw" << std::endl;
}

void risky_function(void){
	throw std::runtime_error("something went wrong");
}

// conditional noexcept: noexcept if the expression is true
template <typename T>
void swap_values(T& a, T& b) noexcept(noexcept(T(std::move(a)))) {
	T tmp = std::move(a);
	a = std::move(b);
	b = std::move(tmp);
}

// noexcept operator: compile-time check, returns bool
void test_noexcept_operator(void);

int main(void){
	safe_function();

	// noexcept operator queries whether expression can throw
	std::cout << "safe_function noexcept? "
			  << noexcept(safe_function()) << std::endl; 	// 1
	std::cout << "risky_function noexcept? "
			  << noexcept(risky_function()) << std::endl; 	// 0

	test_noexcept_operator();
	return (0);
}

void test_noexcept_operator(void){
	int a = 10, b = 20;
	std::cout << "swap_values<int> noexcept? "
			  << noexcept(swap_values(a, b)) << std::endl;

	swap_values(a, b);
	std::cout << "a = " << a << ", b = " << b << std::endl;
}
