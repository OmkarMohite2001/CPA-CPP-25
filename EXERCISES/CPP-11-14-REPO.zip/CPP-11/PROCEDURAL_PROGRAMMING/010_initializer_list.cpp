#include <iostream>
#include <cstdlib>
#include <cassert>

class vector_int{
	private:
		int* p_arr;
		std::size_t size;
	public:
		vector_int(std::size_t arr_size, int default_val=0){
			assert(arr_size > 0);
			p_arr = new int[arr_size];
			size = arr_size;
			for(std::size_t i = 0; i < arr_size; ++i)
				p_arr[i] = default_val;
		}

		vector_int(std::initializer_list<int> init_lst){
			size = init_lst.size();
			p_arr = new int[size];
			std::size_t index = 0;
			for(auto iter = init_lst.begin(); iter != init_lst.end(); ++iter){
				p_arr[index] = *iter;
				++index;
			}
		}

		void show(const char* msg) const{
			if(msg)
				puts(msg);
			for(std::size_t index = 0; index < size; ++index)
				std::cout << "A[" << index << "]:" << p_arr[index] << std::endl;
		}

		~vector_int(){
			delete[] p_arr;
			p_arr = nullptr;
		}
};

int main(void){
	vector_int ivec_1(10, 5);
	vector_int ivec_2{100, 200, 300, 400};
	vector_int* p_ivec = new vector_int{1000, 2000, 3000, 4000};

	ivec_1.show("ivec_1:");
	ivec_2.show("ivec_2:");
	p_ivec->show("ivec_3:");

	delete p_ivec;
	p_ivec = nullptr;

	return (0);
}
