#include <iostream>
#include <string>

// Raw string literal: R"delimiter(...)delimiter"
// No escape sequences are processed inside

void test_basic_raw_strings(void);
void test_with_delimiter(void);

int main(void){
	test_basic_raw_strings();
	test_with_delimiter();
	return (0);
}

void test_basic_raw_strings(void){
	// regular string: backslashes must be escaped
	std::string path1 = "C:\\Users\\yoges\\Documents\\CPA";

	// raw string: backslashes are literal
	std::string path2 = R"(C:\Users\yoges\Documents\CPA)";

	std::cout << "path1: " << path1 << std::endl;
	std::cout << "path2: " << path2 << std::endl;

	// multi-line raw string
	std::string json = R"({
	"name": "CoreCode Academy",
	"city": "Pune",
	"courses": ["C++", "Python", "DSA"]
})";
	std::cout << json << std::endl;

	// regex pattern without escape hell
	std::string regex_old = "\\d{3}-\\d{3}-\\d{4}";
	std::string regex_raw = R"(\d{3}-\d{3}-\d{4})";
	std::cout << "old: " << regex_old << std::endl;
	std::cout << "raw: " << regex_raw << std::endl;
}

void test_with_delimiter(void){
	// when raw string itself contains )" use a custom delimiter
	std::string code = R"xyz(
		std::cout << R"(hello)" << std::endl;
	)xyz";
	std::cout << "code:" << code << std::endl;
}
