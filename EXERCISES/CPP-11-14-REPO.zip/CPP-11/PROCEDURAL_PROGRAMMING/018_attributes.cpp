#include <iostream>
#include <cstdlib>

// C++11 standard attributes: [[noreturn]], [[carries_dependency]]

// [[noreturn]]: function never returns to caller
[[noreturn]] void fatal_error(const char* msg){
	std::cerr << "FATAL: " << msg << std::endl;
	std::abort();
}

[[noreturn]] void infinite_loop(void){
	for(;;){
		// event loop that never terminates
	}
}

// without [[noreturn]], compiler may warn about missing return
int safe_divide(int a, int b){
	if(b == 0)
		fatal_error("division by zero"); 	// compiler knows this path never returns
	return a / b;
}

int main(void){
	int result = safe_divide(10, 2);
	std::cout << "10 / 2 = " << result << std::endl;

	result = safe_divide(100, 5);
	std::cout << "100 / 5 = " << result << std::endl;

	// safe_divide(10, 0); // would call fatal_error and abort

	return (0);
}
