#include <iostream>

// C++98 unscoped enum: names leak into enclosing scope
enum Colour_Old { RED, GREEN, BLUE };
// int RED = 5; 	// error: RED already defined

// C++11 scoped enum: names are scoped, no implicit conversion to int
enum class Colour { Red, Green, Blue };
enum class TrafficLight { Red, Yellow, Green }; 	// no clash with Colour::Red

// underlying type can be specified explicitly
enum class ErrorCode : unsigned int {
	Success = 0,
	NotFound = 404,
	ServerError = 500
};

void test_scoped_enum(void);
void test_underlying_type(void);

int main(void){
	test_scoped_enum();
	test_underlying_type();
	return (0);
}

void test_scoped_enum(void){
	Colour c = Colour::Red;
	TrafficLight t = TrafficLight::Red; 	// no ambiguity

	// int n = c; 			// error: no implicit conversion to int
	int n = static_cast<int>(c); 	// explicit cast required
	std::cout << "Colour::Red as int = " << n << std::endl;

	if(c == Colour::Red)
		std::cout << "Colour is Red" << std::endl;

	// Colour x = 0; 		// error: no implicit conversion from int
}

void test_underlying_type(void){
	ErrorCode ec = ErrorCode::NotFound;
	unsigned int code = static_cast<unsigned int>(ec);
	std::cout << "ErrorCode::NotFound = " << code << std::endl;

	// sizeof depends on underlying type
	std::cout << "sizeof(ErrorCode) = " << sizeof(ErrorCode) << std::endl;
	std::cout << "sizeof(Colour) = " << sizeof(Colour) << std::endl;
}
