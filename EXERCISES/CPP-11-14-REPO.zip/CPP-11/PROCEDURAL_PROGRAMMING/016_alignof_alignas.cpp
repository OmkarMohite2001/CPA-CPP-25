#include <iostream>
#include <cstdint>

// alignof(T): returns alignment requirement of type T
// alignas(N): requests alignment of N bytes for a variable or type

struct Default{
	char c;
	int n;
	double d;
};

struct alignas(16) Aligned16{
	char c;
	int n;
	double d;
};

// alignas on a member
struct PackedData{
	alignas(8) char buffer[3];
	int value;
};

void test_alignof(void);
void test_alignas(void);

int main(void){
	test_alignof();
	test_alignas();
	return (0);
}

void test_alignof(void){
	std::cout << "alignof(char) = " << alignof(char) << std::endl;
	std::cout << "alignof(int) = " << alignof(int) << std::endl;
	std::cout << "alignof(double) = " << alignof(double) << std::endl;
	std::cout << "alignof(long long) = " << alignof(long long) << std::endl;
	std::cout << "alignof(Default) = " << alignof(Default) << std::endl;
	std::cout << "alignof(Aligned16) = " << alignof(Aligned16) << std::endl;

	// sizeof includes padding for alignment
	std::cout << "sizeof(Default) = " << sizeof(Default) << std::endl;
	std::cout << "sizeof(Aligned16) = " << sizeof(Aligned16) << std::endl;
}

void test_alignas(void){
	// force 16-byte alignment on a local variable
	alignas(16) int arr[4] = {10, 20, 30, 40};

	std::cout << "address of arr = " << &arr[0] << std::endl;
	std::cout << "arr aligned to 16? "
			  << (reinterpret_cast<std::uintptr_t>(&arr[0]) % 16 == 0) << std::endl;

	std::cout << "sizeof(PackedData) = " << sizeof(PackedData) << std::endl;
	std::cout << "alignof(PackedData) = " << alignof(PackedData) << std::endl;
}
