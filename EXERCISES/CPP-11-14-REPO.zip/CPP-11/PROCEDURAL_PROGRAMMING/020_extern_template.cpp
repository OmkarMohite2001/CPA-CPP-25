#include <iostream>

// extern template: prevents implicit instantiation in this translation unit
// the instantiation must exist in exactly one other TU

// without extern template, every TU that uses vector_sum<int>
// generates its own instantiation -> redundant code, slower compile

template <typename T>
T vector_sum(const T* arr, std::size_t n){
	T result = T();
	for(std::size_t i = 0; i < n; ++i)
		result = result + arr[i];
	return result;
}

// in a multi-file project, one TU would contain:
//   template int vector_sum<int>(const int*, std::size_t);     // explicit instantiation
// and all other TUs would contain:
//   extern template int vector_sum<int>(const int*, std::size_t); // suppress local instantiation

// explicit instantiation definition (would go in one .cpp file)
template int vector_sum<int>(const int*, std::size_t);
template double vector_sum<double>(const double*, std::size_t);

// for demonstration in single file:
// extern template int vector_sum<int>(const int*, std::size_t);
// ^ in other TUs, this suppresses redundant instantiation

int main(void){
	int iarr[] = {10, 20, 30, 40, 50};
	double darr[] = {1.1, 2.2, 3.3, 4.4, 5.5};

	int isum = vector_sum<int>(iarr, 5);
	double dsum = vector_sum<double>(darr, 5);

	std::cout << "int sum = " << isum << std::endl;
	std::cout << "double sum = " << dsum << std::endl;

	return (0);
}
