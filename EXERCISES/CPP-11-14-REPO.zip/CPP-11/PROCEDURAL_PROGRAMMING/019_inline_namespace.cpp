#include <iostream>

// inline namespace: members are accessible from the enclosing namespace
// primary use case: API versioning

namespace cpa_lib{

	namespace v1{
		void process(int n){
			std::cout << "v1::process(" << n << ")" << std::endl;
		}
	}

	// inline makes v2 the default version
	inline namespace v2{
		void process(int n){
			std::cout << "v2::process(" << n << ")" << std::endl;
		}

		void new_feature(void){
			std::cout << "v2::new_feature()" << std::endl;
		}
	}
}

void test_versioning(void);

int main(void){
	test_versioning();
	return (0);
}

void test_versioning(void){
	// without qualification: picks inline namespace (v2)
	cpa_lib::process(42); 				// calls v2::process

	// explicit version selection
	cpa_lib::v1::process(42); 			// calls v1::process
	cpa_lib::v2::process(42); 			// calls v2::process

	// new_feature is available through cpa_lib directly
	cpa_lib::new_feature();

	// cpa_lib::v1::new_feature(); 	// error: not in v1
}
