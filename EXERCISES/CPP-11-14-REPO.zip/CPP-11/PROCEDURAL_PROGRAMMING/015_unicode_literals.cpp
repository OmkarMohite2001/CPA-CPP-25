#include <iostream>
#include <cstdint>

// C++11 introduces new character types and string literal prefixes
// char16_t : UTF-16 character (at least 16 bits)
// char32_t : UTF-32 character (at least 32 bits)
// u8"..."  : UTF-8 string literal (char[])
// u"..."   : UTF-16 string literal (char16_t[])
// U"..."   : UTF-32 string literal (char32_t[])

void test_char_types(void);
void test_string_prefixes(void);

int main(void){
	test_char_types();
	test_string_prefixes();
	return (0);
}

void test_char_types(void){
	char c1 = 'A'; 				// 1 byte
	char16_t c2 = u'A'; 			// at least 2 bytes
	char32_t c3 = U'A'; 			// at least 4 bytes

	// Devanagari KA: U+0915
	char16_t devanagari_ka = u'\u0915';
	char32_t emoji = U'\U0001F600'; // grinning face emoji

	std::cout << "sizeof(char) = " << sizeof(char) << std::endl;
	std::cout << "sizeof(char16_t) = " << sizeof(char16_t) << std::endl;
	std::cout << "sizeof(char32_t) = " << sizeof(char32_t) << std::endl;

	std::cout << "devanagari_ka code = " << static_cast<uint16_t>(devanagari_ka) << std::endl;
	std::cout << "emoji code = " << static_cast<uint32_t>(emoji) << std::endl;
}

void test_string_prefixes(void){
	// u8 prefix: UTF-8 encoded, type is const char[]
	const char* utf8_str = u8"Hello";

	// u prefix: UTF-16 encoded, type is const char16_t[]
	const char16_t* utf16_str = u"Hello";

	// U prefix: UTF-32 encoded, type is const char32_t[]
	const char32_t* utf32_str = U"Hello";

	std::cout << "sizeof u8 'H' = " << sizeof(utf8_str[0]) << std::endl;
	std::cout << "sizeof u 'H' = " << sizeof(utf16_str[0]) << std::endl;
	std::cout << "sizeof U 'H' = " << sizeof(utf32_str[0]) << std::endl;
}
