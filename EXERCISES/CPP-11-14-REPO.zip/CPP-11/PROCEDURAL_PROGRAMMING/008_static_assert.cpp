#include <iostream>
#include <cstdint>

// static_assert: compile-time assertion
// unlike assert(), this fires at compile time, not runtime

// verify platform assumptions
static_assert(sizeof(int) >= 4, "int must be at least 4 bytes");
static_assert(sizeof(void*) == 8, "This code requires a 64-bit platform");

template <typename T>
class fixed_buffer{
	static_assert(sizeof(T) <= 64, "T is too large for fixed_buffer");

	private:
		T data[256];
	public:
		T& at(std::size_t index){
			return data[index];
		}
};

template <typename T>
T safe_divide(T a, T b){
	static_assert(std::is_floating_point<T>::value,
		"safe_divide requires floating point type");
	return a / b;
}

int main(void){
	fixed_buffer<int> buf1; 	// ok, sizeof(int) <= 64
	buf1.at(0) = 42;
	std::cout << "buf1.at(0) = " << buf1.at(0) << std::endl;

	// fixed_buffer<char[128]> buf2; // error: T is too large for fixed_buffer

	double rs = safe_divide(10.0, 3.0);
	std::cout << "10.0 / 3.0 = " << rs << std::endl;

	// int bad = safe_divide(10, 3); // error: requires floating point type

	return (0);
}
