#include <iostream>
#include <cstdio>

class SmallInt{
	private:
		std::size_t val;
	public:
		SmallInt(int i = 0) : val(i) {
			if(i < 0 || i > 255)
				throw std::runtime_error("Bad val");
		}

		friend std::ostream& operator<<(std::ostream& os, const SmallInt& s){
			os << s.val;
			return os;
		}

		// explicit conversion operator: no implicit conversion to int
		explicit operator int() const {
			return static_cast<int>(val);
		}
};

int main(void){
	SmallInt i(10);

	// int n = i; 			// error: implicit conversion blocked by explicit
	int n = static_cast<int>(i); 	// ok: explicit cast
	std::cout << "n = " << n << std::endl;

	// explicit conversions are allowed in boolean contexts
	SmallInt zero(0);
	SmallInt nonzero(42);

	int j = static_cast<int>(i) + 5;
	std::cout << "j = " << j << std::endl;

	SmallInt k(30);
	double w = static_cast<int>(k) + 3.14;
	std::cout << "w = " << w << std::endl;

	return (0);
}
