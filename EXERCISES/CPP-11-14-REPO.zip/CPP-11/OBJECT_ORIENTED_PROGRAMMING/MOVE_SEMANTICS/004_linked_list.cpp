#include <iostream>
#include <cstdlib>
#include <stdexcept>

class list_invalid_data : public std::runtime_error{
	public:
		list_invalid_data(const char* msg);
};

class list_empty : public std::runtime_error{
	public:
		list_empty(const char* msg);
};

class node{
	friend class list;
	friend std::ostream& operator<<(std::ostream& os, const list& lst_obj);

	private:
		int data;
		node* prev;
		node* next;
		node(int new_data);
};

class list{
	private:
		node* p_head_node;

		static void generic_insert(node* beg, node* mid, node* end);
		static void generic_delete(node* delete_node);
		node* search_node(int data);

	public:
		list(); 					// default ctor
		~list(); 					// dtor

		list(const list& other); 	// copy ctor
		list(list&& other); 		// move ctor

		list& operator=(const list& other); 	// copy assignment
		list& operator=(list&& other); 			// move assignment

		friend std::ostream& operator<<(std::ostream& os, const list& lst_obj);

		void insert_start(int new_data);
		void insert_end(int new_data);
		void insert_after(int e_data, int new_data);
		void insert_before(int e_data, int new_data);
		void remove_end();
		void remove_start();
		void remove_data(int r_data);
		bool find(int data) const;
		bool is_empty() const;
};

int main(void){
	list LL1;
	LL1.insert_end(10);
	LL1.insert_end(20);
	LL1.insert_end(30);
	std::cout << "LL1:" << LL1;

	list LL2(LL1); 					// deep copy
	std::cout << "LL2:" << LL2;

	list LL3(std::move(LL2)); 		// move: LL2 becomes empty
	std::cout << "LL3:" << LL3;
	std::cout << "LL2 after move:" << LL2;

	list LL4;
	LL4.insert_end(100);
	LL4.insert_end(200);

	LL3 = LL4; 						// copy assignment
	std::cout << "LL3 after copy assign:" << LL3;

	LL4 = std::move(LL1); 			// move assignment
	std::cout << "LL4 after move assign:" << LL4;
	std::cout << "LL1 after move:" << LL1;

	return (0);
}

node::node(int new_data) : data(new_data), prev(nullptr), next(nullptr){
}

void list::generic_insert(node* beg, node* mid, node* end){
	mid->next = end;
	mid->prev = beg;
	beg->next = mid;
	end->prev = mid;
}

void list::generic_delete(node* delete_node){
	delete_node->prev->next = delete_node->next;
	delete_node->next->prev = delete_node->prev;
	delete delete_node;
}

node* list::search_node(int data){
	for(node* p_run = p_head_node->next; p_run != p_head_node; p_run = p_run->next)
		if(p_run->data == data)
			return p_run;
	return nullptr;
}

list::list() : p_head_node(new node(0)){
	p_head_node->prev = p_head_node;
	p_head_node->next = p_head_node;
}

list::~list(){
	node* p_run, *p_run_next;
	for(p_run = p_head_node->next; p_run != p_head_node; p_run = p_run_next){
		p_run_next = p_run->next;
		delete p_run;
	}
	delete p_head_node;
	p_head_node = nullptr;
}

list::list(const list& other){
	p_head_node = new node(0);
	p_head_node->prev = p_head_node;
	p_head_node->next = p_head_node;
	for(node* p_run = other.p_head_node->next; p_run != other.p_head_node; p_run = p_run->next)
		insert_end(p_run->data);
}

list::list(list&& other) : p_head_node(other.p_head_node){
	other.p_head_node = new node(0);
	other.p_head_node->prev = other.p_head_node;
	other.p_head_node->next = other.p_head_node;
}

list& list::operator=(const list& other){
	if(this == &other)
		return *this;

	// clear current list
	node* p_run = p_head_node->next;
	while(p_run != p_head_node){
		node* p_next = p_run->next;
		delete p_run;
		p_run = p_next;
	}
	p_head_node->prev = p_head_node;
	p_head_node->next = p_head_node;

	for(node* p = other.p_head_node->next; p != other.p_head_node; p = p->next)
		insert_end(p->data);

	return *this;
}

list& list::operator=(list&& other){
	if(this == &other)
		return *this;

	// clear current list
	node* p_run = p_head_node->next;
	while(p_run != p_head_node){
		node* p_next = p_run->next;
		delete p_run;
		p_run = p_next;
	}
	delete p_head_node;

	p_head_node = other.p_head_node;
	other.p_head_node = new node(0);
	other.p_head_node->prev = other.p_head_node;
	other.p_head_node->next = other.p_head_node;

	return *this;
}

std::ostream& operator<<(std::ostream& os, const list& lst_obj){
	os << "[START]<->";
	for(node* p_run = lst_obj.p_head_node->next; p_run != lst_obj.p_head_node;
		p_run = p_run->next)
		os << "[" << p_run->data << "]<->";
	os << "[END]" << std::endl;
	return os;
}

void list::insert_start(int new_data){
	generic_insert(p_head_node, new node(new_data), p_head_node->next);
}

void list::insert_end(int new_data){
	generic_insert(p_head_node->prev, new node(new_data), p_head_node);
}

void list::insert_after(int e_data, int new_data){
	node* p = search_node(e_data);
	if(p) generic_insert(p, new node(new_data), p->next);
}

void list::insert_before(int e_data, int new_data){
	node* p = search_node(e_data);
	if(p) generic_insert(p->prev, new node(new_data), p);
}

void list::remove_end(){
	if(!is_empty())
		generic_delete(p_head_node->prev);
}

void list::remove_start(){
	if(!is_empty())
		generic_delete(p_head_node->next);
}

void list::remove_data(int r_data){
	node* p = search_node(r_data);
	if(p) generic_delete(p);
}

bool list::find(int data) const{
	node* p_run = const_cast<list*>(this)->search_node(data);
	return (p_run != nullptr);
}

bool list::is_empty() const{
	return (p_head_node->prev == p_head_node && p_head_node->next == p_head_node);
}

list_invalid_data::list_invalid_data(const char* msg) : std::runtime_error(msg){
}

list_empty::list_empty(const char* msg) : std::runtime_error(msg){
}
