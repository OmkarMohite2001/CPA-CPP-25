#include <iostream>
#include <cstdlib>
#include <cassert>

class array{
	private:
		int* pa;
		std::size_t size;

	public:
		array(std::size_t arr_size){
			assert(arr_size > 0);
			pa = new int[arr_size];
			size = arr_size;
		}

		array(const array& other) = delete;
		array& operator=(const array& other) = delete;

		array(array&& other){
			pa = other.pa;
			size = other.size;
			other.pa = nullptr;
			other.size = 0;
		}

		array& operator=(array&& other){
			if(pa)
				delete[] pa;
			pa = other.pa;
			size = other.size;
			other.pa = nullptr;
			other.size = 0;
			return *this;
		}

		int at(std::size_t index){
			assert(index < size);
			return pa[index];
		}

		void set(std::size_t index, int element){
			assert(index < size);
			pa[index] = element;
		}

		~array(){
			delete[] pa;
			pa = nullptr;
			size = 0;
		}
};

int main(void){
	array A1(5);
	array A2(10);

	for(std::size_t i = 0; i < 5; ++i)
		A1.set(i, (i+1)*5);

	for(std::size_t i = 0; i < 10; ++i)
		A2.set(i, (i+1)*10);

	array A3(std::move(A1));
	A2 = std::move(A3);

	return (0);
}
