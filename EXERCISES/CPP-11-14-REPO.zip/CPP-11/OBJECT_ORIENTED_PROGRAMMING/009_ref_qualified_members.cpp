#include <iostream>
#include <string>

// ref-qualifiers on member functions: & (lvalue) and && (rvalue)
// overload based on whether *this is an lvalue or rvalue

class TextBuffer{
	private:
		std::string data;
	public:
		TextBuffer(const std::string& s) : data(s) {}

		// called when *this is an lvalue: return copy
		std::string contents() const & {
			std::cout << "contents() & : returning copy" << std::endl;
			return data;
		}

		// called when *this is an rvalue: can move
		std::string contents() && {
			std::cout << "contents() && : moving out" << std::endl;
			return std::move(data);
		}
};

TextBuffer make_buffer(void){
	return TextBuffer("temporary data");
}

int main(void){
	TextBuffer buf("hello world");

	// buf is an lvalue -> calls contents() &
	std::string s1 = buf.contents();
	std::cout << "s1 = " << s1 << std::endl;

	// make_buffer() returns an rvalue -> calls contents() &&
	std::string s2 = make_buffer().contents();
	std::cout << "s2 = " << s2 << std::endl;

	// explicit move -> calls contents() &&
	std::string s3 = std::move(buf).contents();
	std::cout << "s3 = " << s3 << std::endl;

	return (0);
}
