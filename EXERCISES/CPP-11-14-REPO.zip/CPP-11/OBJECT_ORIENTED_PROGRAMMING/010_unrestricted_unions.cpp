#include <iostream>
#include <string>
#include <new>

// C++11 lifts the restriction that union members cannot have
// non-trivial constructors/destructors
// You must manage member lifetime manually with placement new

union Token{
	int int_val;
	double dbl_val;
	std::string str_val; 	// non-trivial type: was illegal in C++98

	// must provide constructor and destructor
	Token() : int_val(0) {}
	~Token() {} 	// caller must destroy active member manually
};

enum class TokenType { Int, Double, String };

// safe wrapper that tracks which member is active
class SafeToken{
	private:
		Token tok;
		TokenType active;

		void destroy_active(void){
			if(active == TokenType::String)
				tok.str_val.~basic_string(); 	// explicit destructor call
		}

	public:
		SafeToken() : active(TokenType::Int) {}

		void set_int(int n){
			destroy_active();
			tok.int_val = n;
			active = TokenType::Int;
		}

		void set_double(double d){
			destroy_active();
			tok.dbl_val = d;
			active = TokenType::Double;
		}

		void set_string(const std::string& s){
			destroy_active();
			new (&tok.str_val) std::string(s); 	// placement new
			active = TokenType::String;
		}

		void show() const {
			switch(active){
				case TokenType::Int:
					std::cout << "int: " << tok.int_val << std::endl; break;
				case TokenType::Double:
					std::cout << "double: " << tok.dbl_val << std::endl; break;
				case TokenType::String:
					std::cout << "string: " << tok.str_val << std::endl; break;
			}
		}

		~SafeToken(){
			destroy_active();
		}
};

int main(void){
	SafeToken t;

	t.set_int(42);
	t.show();

	t.set_double(3.14);
	t.show();

	t.set_string("CoreCode Academy");
	t.show();

	t.set_int(100);
	t.show();

	return (0);
}
