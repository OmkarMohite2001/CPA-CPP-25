#include <iostream>
#include <string>

// Variadic templates: template parameter pack + function parameter pack
// The mechanism behind std::make_shared, emplace_back, std::forward

// base case: zero arguments
void print(void){
	std::cout << std::endl;
}

// recursive case: peel off one argument, recurse on the rest
template <typename T, typename... Args>
void print(T first, Args... rest){
	std::cout << first;
	if(sizeof...(rest) > 0)
		std::cout << ", ";
	print(rest...);
}

// sizeof... operator: number of elements in a parameter pack
template <typename... Args>
std::size_t count_args(Args... args){
	return sizeof...(args);
}

// practical example: type-safe sum of arbitrary number of arguments
template <typename T>
T sum(T val){
	return val; 	// base case
}

template <typename T, typename... Args>
T sum(T first, Args... rest){
	return first + sum(rest...);
}

// emplace-style: perfect forwarding with variadic templates
template <typename T, typename... Args>
T* heap_construct(Args&&... args){
	return new T(std::forward<Args>(args)...);
}

class Point{
	private:
		double x, y, z;
	public:
		Point(double _x, double _y, double _z) : x(_x), y(_y), z(_z){
		}
		void show() const {
			std::cout << "(" << x << ", " << y << ", " << z << ")" << std::endl;
		}
};

int main(void){
	// print with mixed types
	print(1, 2.5, "hello", 'A');
	print(std::string("CoreCode"), 42);
	print(); 	// base case only

	// count_args
	std::cout << "count_args(1,2,3) = " << count_args(1, 2, 3) << std::endl;
	std::cout << "count_args() = " << count_args() << std::endl;

	// type-safe sum
	std::cout << "sum(1,2,3,4,5) = " << sum(1, 2, 3, 4, 5) << std::endl;
	std::cout << "sum(1.1, 2.2, 3.3) = " << sum(1.1, 2.2, 3.3) << std::endl;

	// perfect forwarding construction
	Point* p = heap_construct<Point>(1.0, 2.0, 3.0);
	p->show();
	delete p;

	return (0);
}
