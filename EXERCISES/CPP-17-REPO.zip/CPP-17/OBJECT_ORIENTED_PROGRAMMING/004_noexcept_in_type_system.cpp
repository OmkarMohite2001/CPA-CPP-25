#include <iostream>

// C++17: noexcept is now part of the function type
// void(*)() noexcept is a DIFFERENT type from void(*)()
// a noexcept function pointer can be assigned to a non-noexcept pointer (widening)
// but NOT the reverse (narrowing)

void safe_func(void) noexcept {
	std::cout << "safe_func: guaranteed no throw" << std::endl;
}

void risky_func(void){
	std::cout << "risky_func: may throw" << std::endl;
}

// noexcept affects function pointer types
using safe_ptr_t = void(*)() noexcept;
using any_ptr_t = void(*)();

void call_it(any_ptr_t f){
	f();
}

void call_safe(safe_ptr_t f){
	f();
}

void test_type_distinction(void);

int main(void){
	test_type_distinction();
	return (0);
}

void test_type_distinction(void){
	// noexcept function can bind to non-noexcept pointer (safe widening)
	any_ptr_t p1 = safe_func; 	// ok
	any_ptr_t p2 = risky_func; // ok

	// non-noexcept function CANNOT bind to noexcept pointer
	safe_ptr_t p3 = safe_func; // ok
	// safe_ptr_t p4 = risky_func; // error in C++17: type mismatch

	// passing noexcept function where non-noexcept is expected: ok
	call_it(safe_func);
	call_it(risky_func);

	// passing non-noexcept function where noexcept is expected: error
	call_safe(safe_func);
	// call_safe(risky_func); // error: cannot convert

	p1();
	p2();
	p3();
}
