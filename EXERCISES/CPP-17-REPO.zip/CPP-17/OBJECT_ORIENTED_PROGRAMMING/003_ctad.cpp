#include <iostream>
#include <vector>
#include <utility>

// Class Template Argument Deduction (CTAD)
// compiler deduces template arguments from constructor arguments
// no need to write angle brackets when types can be inferred

// custom class with deduction
template <typename T>
class Wrapper{
	private:
		T value;
	public:
		Wrapper(T val) : value(val) {}

		T get() const { return value; }

		friend std::ostream& operator<<(std::ostream& os, const Wrapper& w){
			os << w.value;
			return os;
		}
};

// deduction guide (optional, for non-obvious cases)
// Wrapper(const char*) -> Wrapper<std::string>;

template <typename T1, typename T2>
class Pair{
	private:
		T1 first;
		T2 second;
	public:
		Pair(T1 f, T2 s) : first(f), second(s) {}

		void show() const {
			std::cout << "(" << first << ", " << second << ")" << std::endl;
		}
};

int main(void){
	// C++14: must specify template arguments
	// std::pair<int, double> p(1, 2.0);

	// C++17: deduced from constructor arguments
	std::pair p(1, 2.0); 	// deduced as std::pair<int, double>
	std::cout << "pair: " << p.first << ", " << p.second << std::endl;

	// works with custom types
	Wrapper w1(42); 		// Wrapper<int>
	Wrapper w2(3.14); 		// Wrapper<double>
	Wrapper w3("hello"); 	// Wrapper<const char*>
	std::cout << "w1=" << w1 << " w2=" << w2 << " w3=" << w3 << std::endl;

	Pair cp(std::string("age"), 25); 	// Pair<std::string, int>
	cp.show();

	// std::vector with CTAD
	std::vector v{1, 2, 3, 4, 5}; 	// std::vector<int>
	for(const auto& elem : v)
		std::cout << elem << " ";
	std::cout << std::endl;

	return (0);
}
