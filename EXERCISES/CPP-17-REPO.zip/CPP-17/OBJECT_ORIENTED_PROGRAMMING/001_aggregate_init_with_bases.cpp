#include <iostream>

// C++17: aggregate initialization extended to types with base classes
// C++14 aggregates could not have base classes

struct Point{
	double x;
	double y;
};

struct NamedPoint : Point{
	const char* label;
};

// multi-level base
struct Base1{
	int a;
};

struct Base2{
	int b;
};

struct Derived : Base1, Base2{
	int c;
};

int main(void){
	// base class members come first in the brace list
	NamedPoint np = {{1.0, 2.0}, "origin-ish"};
	std::cout << np.label << ": (" << np.x << ", " << np.y << ")" << std::endl;

	// multiple bases: one brace-group per base, then derived members
	Derived d = {{10}, {20}, 30};
	std::cout << "a=" << d.a << " b=" << d.b << " c=" << d.c << std::endl;

	// can also use nested braces explicitly
	NamedPoint np2 = {{3.0, 4.0}, "point-two"};
	std::cout << np2.label << ": (" << np2.x << ", " << np2.y << ")" << std::endl;

	return (0);
}
