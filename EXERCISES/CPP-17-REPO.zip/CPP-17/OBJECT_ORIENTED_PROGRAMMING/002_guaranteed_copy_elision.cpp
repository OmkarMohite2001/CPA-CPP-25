#include <iostream>

// C++17 mandates copy/move elision in certain contexts
// Previously, the compiler was allowed but not required to elide
// Now: when a prvalue is used to initialize an object of the same type,
// no copy/move constructor is called — guaranteed by the standard

class Heavy{
	private:
		int id;
	public:
		Heavy(int _id) : id(_id){
			std::cout << "Heavy(" << id << ") constructed" << std::endl;
		}

		Heavy(const Heavy& other) : id(other.id){
			std::cout << "Heavy(" << id << ") COPY constructed" << std::endl;
		}

		Heavy(Heavy&& other) : id(other.id){
			other.id = -1;
			std::cout << "Heavy(" << id << ") MOVE constructed" << std::endl;
		}

		void show() const {
			std::cout << "Heavy id=" << id << std::endl;
		}
};

// returns a prvalue — C++17 guarantees no copy/move
Heavy create_heavy(int id){
	return Heavy(id);
}

// even with deleted copy/move — this compiles in C++17
class NonCopyable{
	private:
		int val;
	public:
		NonCopyable(int v) : val(v) {}
		NonCopyable(const NonCopyable&) = delete;
		NonCopyable(NonCopyable&&) = delete;

		int get() const { return val; }
};

NonCopyable make_nc(int v){
	return NonCopyable(v); 	// ok in C++17: no copy/move needed
}

int main(void){
	std::cout << "--- prvalue initialization ---" << std::endl;
	Heavy h = create_heavy(1); 	// guaranteed: only one construction
	h.show();

	std::cout << "--- direct prvalue ---" << std::endl;
	Heavy h2 = Heavy(2); 		// guaranteed: no copy/move
	h2.show();

	std::cout << "--- non-copyable prvalue ---" << std::endl;
	NonCopyable nc = make_nc(42);
	std::cout << "nc.get() = " << nc.get() << std::endl;

	return (0);
}
