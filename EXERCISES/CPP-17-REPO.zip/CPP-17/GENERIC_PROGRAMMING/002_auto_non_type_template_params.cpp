#include <iostream>

// C++17: auto for non-type template parameters
// allows a template to accept any compile-time constant without specifying its type
// the type is deduced from the argument

// before C++17: separate templates for int, char, etc.
// template <int N> struct OldStyle {};
// template <char C> struct OldStyle2 {};

// C++17: one template handles all non-type parameter types
template <auto N>
struct Constant{
	using type = decltype(N);

	static constexpr auto value = N;

	void show() const {
		std::cout << "value=" << value
				  << " sizeof=" << sizeof(N) << std::endl;
	}
};

// practical: compile-time array with deduced size type
template <auto Size>
class FixedBuffer{
	private:
		int data[Size];
	public:
		FixedBuffer(){
			for(decltype(Size) i = 0; i < Size; ++i)
				data[i] = 0;
		}

		void set(decltype(Size) index, int val){
			data[index] = val;
		}

		int get(decltype(Size) index) const {
			return data[index];
		}

		static constexpr auto size(void){
			return Size;
		}
};

// heterogeneous constant list using auto NTTP
template <auto... Vals>
struct ValueList{
	static void print(void){
		((std::cout << Vals << " "), ...); 	// fold expression from C++17
		std::cout << std::endl;
	}
};

int main(void){
	Constant<42> c1;
	Constant<'A'> c2;
	Constant<true> c3;

	c1.show(); 	// value=42, sizeof=4
	c2.show(); 	// value=A, sizeof=1
	c3.show(); 	// value=1, sizeof=1

	FixedBuffer<10> buf;
	buf.set(0, 100);
	buf.set(9, 999);
	std::cout << "buf[0]=" << buf.get(0) << std::endl;
	std::cout << "buf[9]=" << buf.get(9) << std::endl;
	std::cout << "buf.size()=" << buf.size() << std::endl;

	// mix of types in a single value list
	ValueList<1, 'X', true, 42>::print();

	return (0);
}
