#include <iostream>
#include <string>

// Fold expressions: apply an operator over a parameter pack
// replaces the recursive base-case pattern from C++11 variadic templates
//
// Four forms:
// (pack op ...)      unary right fold
// (... op pack)      unary left fold
// (pack op ... op init)  binary right fold
// (init op ... op pack)  binary left fold

// unary left fold: ((arg1 + arg2) + arg3) + ...
template <typename... Args>
auto sum(Args... args){
	return (... + args);
}

// unary right fold with logical AND: arg1 && (arg2 && (arg3 && ...))
template <typename... Args>
bool all_true(Args... args){
	return (args && ...);
}

// binary left fold with initial value: ((init + arg1) + arg2) + ...
template <typename... Args>
auto sum_from(int init, Args... args){
	return (init + ... + args);
}

// fold with comma operator: execute each expression in order
template <typename... Args>
void print_all(Args... args){
	((std::cout << args << " "), ...);
	std::cout << std::endl;
}

// practical: check if any argument matches a value
template <typename T, typename... Args>
bool contains(T target, Args... args){
	return ((args == target) || ...);
}

int main(void){
	std::cout << "sum(1,2,3,4,5) = " << sum(1, 2, 3, 4, 5) << std::endl;
	std::cout << "sum(1.1, 2.2, 3.3) = " << sum(1.1, 2.2, 3.3) << std::endl;

	std::cout << "all_true(true,true,true) = " << all_true(true, true, true) << std::endl;
	std::cout << "all_true(true,false,true) = " << all_true(true, false, true) << std::endl;

	std::cout << "sum_from(100, 1,2,3) = " << sum_from(100, 1, 2, 3) << std::endl;

	print_all(1, "hello", 3.14, 'A');

	std::cout << "contains(3, 1,2,3,4,5) = " << contains(3, 1, 2, 3, 4, 5) << std::endl;
	std::cout << "contains(9, 1,2,3,4,5) = " << contains(9, 1, 2, 3, 4, 5) << std::endl;

	// string concatenation via fold
	auto concat = [](auto... args){
		return (std::string{} + ... + std::string(args));
	};
	std::cout << concat("Core", "Code", "Academy") << std::endl;

	return (0);
}
