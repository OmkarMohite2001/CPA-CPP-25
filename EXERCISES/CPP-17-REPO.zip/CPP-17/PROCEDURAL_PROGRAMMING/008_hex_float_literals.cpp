#include <iostream>
#include <cstdio>

// C++17: hexadecimal floating-point literals
// syntax: 0xMMMpEEE where MMM is hex mantissa, EEE is binary exponent
// value = MMM * 2^EEE
// useful for exact representation of floating-point constants

int main(void){
	// 0x1.0p0 = 1.0 * 2^0 = 1.0
	double one = 0x1.0p0;
	std::cout << "0x1.0p0 = " << one << std::endl;

	// 0x1.0p4 = 1.0 * 2^4 = 16.0
	double sixteen = 0x1.0p4;
	std::cout << "0x1.0p4 = " << sixteen << std::endl;

	// 0x1.8p1 = 1.5 * 2^1 = 3.0
	// (0x1.8 in hex = 1 + 8/16 = 1.5 in decimal)
	double three = 0x1.8p1;
	std::cout << "0x1.8p1 = " << three << std::endl;

	// useful for precise constants (no decimal rounding issues)
	double smallest_normal = 0x1.0p-1022;
	printf("smallest normal double: %e\n", smallest_normal);

	// negative exponent
	double quarter = 0x1.0p-2; 	// 1.0 * 2^-2 = 0.25
	std::cout << "0x1.0p-2 = " << quarter << std::endl;

	return (0);
}
