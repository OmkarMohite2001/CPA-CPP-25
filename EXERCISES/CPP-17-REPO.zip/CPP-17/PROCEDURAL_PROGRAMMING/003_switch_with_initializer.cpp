#include <iostream>

// switch with initializer: switch(init; expr)
// same scoping benefit as if-with-initializer

enum class Status { Ok, Warning, Error };

Status get_status(int code){
	if(code == 0) return Status::Ok;
	if(code == 1) return Status::Warning;
	return Status::Error;
}

int main(void){
	// variable scoped to the switch block
	switch(Status s = get_status(1); s){
		case Status::Ok:
			std::cout << "All good" << std::endl;
			break;
		case Status::Warning:
			std::cout << "Warning detected" << std::endl;
			break;
		case Status::Error:
			std::cout << "Error occurred" << std::endl;
			break;
	}
	// s is not visible here

	// with a computed value
	switch(int n = 15 % 4; n){
		case 0: std::cout << "divisible by 4" << std::endl; break;
		case 1: std::cout << "remainder 1" << std::endl; break;
		case 2: std::cout << "remainder 2" << std::endl; break;
		case 3: std::cout << "remainder 3" << std::endl; break;
	}

	return (0);
}
