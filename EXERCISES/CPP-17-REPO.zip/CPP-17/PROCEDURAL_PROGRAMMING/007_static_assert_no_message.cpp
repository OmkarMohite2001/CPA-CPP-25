#include <iostream>
#include <type_traits>

// C++17: static_assert with no message string
// C++11 required: static_assert(expr, "message")
// C++17 allows:   static_assert(expr)

static_assert(sizeof(int) >= 4);
static_assert(sizeof(void*) == 8);

template <typename T>
T safe_negate(T val){
	static_assert(std::is_signed<T>::value); 	// no message needed
	return -val;
}

// the message form still works and is preferred when intent is non-obvious
static_assert(sizeof(long long) >= 8, "long long must be at least 8 bytes");

int main(void){
	int n = safe_negate(-42);
	std::cout << "safe_negate(-42) = " << n << std::endl;

	double d = safe_negate(-3.14);
	std::cout << "safe_negate(-3.14) = " << d << std::endl;

	// unsigned int u = safe_negate(42u); // static_assert fires

	return (0);
}
