#include <iostream>

// inline variables: can be defined in headers without ODR violations
// solves the classic "define global in header" problem
// the linker picks one definition and discards duplicates

// in a header file, you can now write:
// inline int max_connections = 100;
// inline const char* app_name = "CPA";

// before C++17 you needed a .cpp file for the definition

struct Config{
	// inline static members can be initialized in-class
	inline static int max_retries = 3;
	inline static double timeout = 5.0;
	inline static const char* version = "1.0.0";
};

// inline constexpr was already implicitly inline in C++14 for static members
// C++17 makes inline explicit and extends it to non-constexpr

// inline variable at namespace scope
inline int global_counter = 0;

void increment(void){
	++global_counter;
}

int main(void){
	std::cout << "version: " << Config::version << std::endl;
	std::cout << "max_retries: " << Config::max_retries << std::endl;
	std::cout << "timeout: " << Config::timeout << std::endl;

	Config::max_retries = 5; 	// modifiable
	std::cout << "max_retries after change: " << Config::max_retries << std::endl;

	increment();
	increment();
	increment();
	std::cout << "global_counter: " << global_counter << std::endl;

	return (0);
}
