#include <iostream>

// C++17 nested namespace definition
// C++11/14 required separate nesting

// C++11 way:
// namespace A {
//     namespace B {
//         namespace C {
//             void f() {}
//         }
//     }
// }

// C++17 way: compact nested namespace
namespace CPA::Math::Linear {
	double dot_product(const double* a, const double* b, int n){
		double result = 0.0;
		for(int i = 0; i < n; ++i)
			result += a[i] * b[i];
		return result;
	}
}

namespace CPA::Math::Stats {
	double mean(const double* arr, int n){
		double sum = 0.0;
		for(int i = 0; i < n; ++i)
			sum += arr[i];
		return sum / n;
	}
}

int main(void){
	double a[] = {1.0, 2.0, 3.0};
	double b[] = {4.0, 5.0, 6.0};

	double dp = CPA::Math::Linear::dot_product(a, b, 3);
	std::cout << "dot product = " << dp << std::endl;

	double m = CPA::Math::Stats::mean(a, 3);
	std::cout << "mean = " << m << std::endl;

	return (0);
}
