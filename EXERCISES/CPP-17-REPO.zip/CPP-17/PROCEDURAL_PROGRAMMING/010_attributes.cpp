#include <iostream>

// C++17 adds three new standard attributes:
// [[nodiscard]], [[maybe_unused]], [[fallthrough]]

// [[nodiscard]]: warns if return value is discarded
[[nodiscard]] int compute_hash(const char* str){
	int hash = 0;
	while(*str)
		hash = hash * 31 + *str++;
	return hash;
}

// can be applied to types
struct [[nodiscard]] ErrorCode{
	int code;
	const char* message;
};

ErrorCode validate(int n){
	if(n < 0)
		return {-1, "negative value"};
	return {0, "ok"};
}

// [[maybe_unused]]: suppresses unused-variable/parameter warnings
void debug_log([[maybe_unused]] const char* msg, [[maybe_unused]] int level){
#ifdef DEBUG
	std::cout << "[" << level << "] " << msg << std::endl;
#endif
}

// [[fallthrough]]: explicit intent to fall through in switch
void classify(int n){
	switch(n){
		case 1:
			std::cout << "one, ";
			[[fallthrough]]; 	// intentional fall-through
		case 2:
			std::cout << "small number" << std::endl;
			break;
		case 3:
			std::cout << "three" << std::endl;
			break;
		default:
			std::cout << "other" << std::endl;
			break;
	}
}

int main(void){
	// [[nodiscard]] in action
	int h = compute_hash("hello");
	std::cout << "hash: " << h << std::endl;
	// compute_hash("test"); // warning: discarding nodiscard return value

	ErrorCode ec = validate(42);
	std::cout << "validate(42): " << ec.message << std::endl;
	// validate(-1); // warning: discarding nodiscard type

	// [[maybe_unused]]
	[[maybe_unused]] int debug_counter = 0; 	// no warning even though unused

	debug_log("startup", 1);

	// [[fallthrough]]
	classify(1); 	// prints "one, small number"
	classify(2); 	// prints "small number"
	classify(3); 	// prints "three"

	return (0);
}
