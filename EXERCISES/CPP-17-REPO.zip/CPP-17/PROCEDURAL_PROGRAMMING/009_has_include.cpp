#include <iostream>

// __has_include: preprocessor predicate
// checks if a header is available before including it
// useful for portability and feature detection

#if __has_include(<optional>)
	#include <optional>
	#define HAS_OPTIONAL 1
#else
	#define HAS_OPTIONAL 0
#endif

#if __has_include(<cstdio>)
	#include <cstdio>
	#define HAS_CSTDIO 1
#else
	#define HAS_CSTDIO 0
#endif

// checking for a header that likely does not exist
#if __has_include(<nonexistent_header.h>)
	#define HAS_NONEXISTENT 1
#else
	#define HAS_NONEXISTENT 0
#endif

int main(void){
	std::cout << "has <optional>: " << HAS_OPTIONAL << std::endl;
	std::cout << "has <cstdio>: " << HAS_CSTDIO << std::endl;
	std::cout << "has <nonexistent_header.h>: " << HAS_NONEXISTENT << std::endl;

#if HAS_OPTIONAL
	std::optional<int> opt = 42;
	std::cout << "optional value: " << opt.value() << std::endl;
#endif

	return (0);
}
