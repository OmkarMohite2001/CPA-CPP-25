#include <iostream>
#include <type_traits>
#include <string>

// if constexpr: compile-time branch elimination
// the discarded branch is not instantiated (unlike regular if)
// primary use: simplifying template code that previously needed SFINAE or tag dispatch

// simple case: different behaviour for integral vs floating point
template <typename T>
std::string type_description(T val){
	if constexpr(std::is_integral<T>::value){
		return "integral: " + std::to_string(val);
	} else if constexpr(std::is_floating_point<T>::value){
		return "floating: " + std::to_string(val);
	} else {
		return "other type";
	}
}

// replaces the recursive variadic template base case pattern
template <typename T>
T sum(T val){
	return val;
}

template <typename T, typename... Args>
T sum(T first, Args... rest){
	if constexpr(sizeof...(rest) == 0)
		return first;
	else
		return first + sum(rest...);
}

// compile-time selection of algorithm
template <typename T>
T absolute(T val){
	if constexpr(std::is_unsigned<T>::value)
		return val; 	// unsigned can never be negative
	else
		return (val < 0) ? -val : val;
}

int main(void){
	std::cout << type_description(42) << std::endl;
	std::cout << type_description(3.14) << std::endl;
	std::cout << type_description('A') << std::endl;

	std::cout << "sum(1,2,3,4,5) = " << sum(1, 2, 3, 4, 5) << std::endl;

	std::cout << "absolute(-42) = " << absolute(-42) << std::endl;
	std::cout << "absolute(42u) = " << absolute(42u) << std::endl;

	return (0);
}
