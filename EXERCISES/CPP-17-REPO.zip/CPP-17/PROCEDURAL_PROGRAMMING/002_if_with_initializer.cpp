#include <iostream>
#include <map>
#include <string>

// if with initializer: if(init; condition)
// the variable declared in init is scoped to the if-else block

void test_basic_if_init(void);
void test_map_insert(void);

int main(void){
	test_basic_if_init();
	test_map_insert();
	return (0);
}

void test_basic_if_init(void){
	// without initializer (C++11): variable leaks into outer scope
	// {
	//     int val = compute();
	//     if(val > 0) { ... }
	//     // val still visible here
	// }

	// with initializer (C++17): val is scoped to if-else
	if(int val = 42; val > 0){
		std::cout << "positive: " << val << std::endl;
	} else {
		std::cout << "non-positive: " << val << std::endl;
	}
	// val is not visible here
}

void test_map_insert(void){
	std::map<std::string, int> m{{"alpha", 1}, {"beta", 2}};

	// structured binding + if-init: the canonical C++17 pattern
	if(auto [iter, success] = m.insert({"gamma", 3}); success){
		std::cout << "inserted: " << iter->first << "=" << iter->second << std::endl;
	} else {
		std::cout << "key already exists" << std::endl;
	}

	// attempt duplicate insert
	if(auto [iter, success] = m.insert({"alpha", 99}); !success){
		std::cout << "alpha already exists with value " << iter->second << std::endl;
	}
}
