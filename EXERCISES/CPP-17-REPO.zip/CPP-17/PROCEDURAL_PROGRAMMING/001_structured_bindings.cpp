#include <iostream>
#include <map>
#include <string>

// Structured bindings: decompose an object into named variables
// Works with arrays, structs/classes with public members, and std::pair/tuple

struct Point{
	double x;
	double y;
	double z;
};

Point get_origin(void){
	return {0.0, 0.0, 0.0};
}

void test_array_binding(void);
void test_struct_binding(void);
void test_pair_binding(void);
void test_map_iteration(void);

int main(void){
	test_array_binding();
	test_struct_binding();
	test_pair_binding();
	test_map_iteration();
	return (0);
}

void test_array_binding(void){
	int arr[] = {10, 20, 30};
	auto [a, b, c] = arr;
	std::cout << "a=" << a << " b=" << b << " c=" << c << std::endl;

	// by reference: modifications affect the original
	auto& [x, y, z] = arr;
	x = 100;
	std::cout << "arr[0] after x=100: " << arr[0] << std::endl;
}

void test_struct_binding(void){
	auto [px, py, pz] = get_origin();
	std::cout << "origin: " << px << ", " << py << ", " << pz << std::endl;

	Point p{1.0, 2.0, 3.0};
	const auto& [rx, ry, rz] = p; 	// const reference binding
	std::cout << "point: " << rx << ", " << ry << ", " << rz << std::endl;
}

void test_pair_binding(void){
	std::pair<int, std::string> data{42, "hello"};
	auto [num, str] = data;
	std::cout << "num=" << num << " str=" << str << std::endl;
}

void test_map_iteration(void){
	std::map<std::string, int> scores{
		{"Alice", 95}, {"Bob", 87}, {"Charlie", 92}
	};

	// C++11 way: iter->first, iter->second
	// C++17 way: structured bindings
	for(const auto& [name, score] : scores)
		std::cout << name << ": " << score << std::endl;
}
