#include <iostream>
#include <functional>

// C++17: [*this] captures a COPY of the enclosing object
// C++11 [this] captures the pointer — dangerous if object is destroyed

class Timer{
	private:
		int interval;
		std::string name;
	public:
		Timer(int ms, const std::string& n) : interval(ms), name(n) {}

		// C++11 [this]: captures pointer, dangles if Timer is destroyed
		std::function<void()> get_callback_11(void){
			return [this](){
				std::cout << "[this] " << name << " interval=" << interval << std::endl;
			};
		}

		// C++17 [*this]: captures a copy of the entire Timer object
		std::function<void()> get_callback_17(void){
			return [*this](){
				std::cout << "[*this] " << name << " interval=" << interval << std::endl;
			};
		}
};

void test_dangling_this(void);
void test_safe_copy(void);

int main(void){
	test_safe_copy();
	return (0);
}

void test_safe_copy(void){
	std::function<void()> callback;

	{
		Timer t(500, "heartbeat");

		// [*this] captures a copy — safe even after t is destroyed
		callback = t.get_callback_17();
	}
	// t is destroyed here

	// callback still works: it holds its own copy of the Timer
	callback();
}
