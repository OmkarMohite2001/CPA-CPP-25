#include <iostream>

// C++17: lambdas are implicitly constexpr when possible
// can also be explicitly marked constexpr

void test_implicit_constexpr(void);
void test_explicit_constexpr(void);

int main(void){
	test_implicit_constexpr();
	test_explicit_constexpr();
	return (0);
}

void test_implicit_constexpr(void){
	// this lambda is implicitly constexpr because its body qualifies
	auto square = [](int x){ return x * x; };

	// can be used in compile-time contexts
	constexpr int val = square(5); 	// evaluated at compile time
	std::cout << "square(5) = " << val << std::endl;

	static_assert(square(6) == 36); // compile-time assertion

	// still works at runtime too
	int n = 7;
	std::cout << "square(7) = " << square(n) << std::endl;
}

void test_explicit_constexpr(void){
	// explicitly constexpr lambda
	auto factorial = [](int n) constexpr -> int {
		int result = 1;
		for(int i = 2; i <= n; ++i) 	// C++14 relaxed constexpr allows loops
			result *= i;
		return result;
	};

	constexpr int f6 = factorial(6);
	std::cout << "factorial(6) = " << f6 << std::endl;
	static_assert(factorial(5) == 120);

	// constexpr lambda with captures
	constexpr int base = 10;
	auto add_base = [base](int x) constexpr { return x + base; };
	constexpr int result = add_base(5);
	std::cout << "add_base(5) = " << result << std::endl;
	static_assert(add_base(3) == 13);
}
